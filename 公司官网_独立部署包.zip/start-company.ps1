$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$dataDir = Join-Path $root 'data'
New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
$runtimePath = Join-Path $dataDir 'runtime.json'
$credentialPath = Join-Path $dataDir 'admin-password.dpapi'
if (!(Test-Path $credentialPath)) {
    $bytes = New-Object byte[] 36
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $secret = [Convert]::ToBase64String($bytes)
    ConvertTo-SecureString $secret -AsPlainText -Force | ConvertFrom-SecureString | Set-Content $credentialPath -Encoding UTF8
    $secret = $null
}
if (!(Test-Path $runtimePath)) {
    $pythonPath = (Get-Command python -ErrorAction Stop).Source
    @{python=$pythonPath;host='127.0.0.1';port=8188} | ConvertTo-Json | Set-Content $runtimePath -Encoding UTF8
}
$config = Get-Content $runtimePath -Raw -Encoding UTF8 | ConvertFrom-Json
$listener = Get-NetTCPConnection -LocalPort $config.port -State Listen -ErrorAction SilentlyContinue
if ($listener) { throw 'Configured company website port is already in use. No process was changed.' }
$secure = (Get-Content $credentialPath -Raw -Encoding UTF8).Trim() | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PSCredential('company-admin', $secure)
$env:COMPANY_ADMIN_PASSWORD = $credential.GetNetworkCredential().Password
$env:COMPANY_HOST = $config.host
$env:COMPANY_PORT = [string]$config.port
$env:COMPANY_DATA_DIR = $dataDir
$env:COMPANY_SECURE_COOKIE = '0'
$env:PYTHONDONTWRITEBYTECODE = '1'
try {
    $process = Start-Process -FilePath $config.python -ArgumentList ('"' + (Join-Path $root 'server.py') + '"') -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $dataDir 'service.stdout.log') -RedirectStandardError (Join-Path $dataDir 'service.stderr.log') -PassThru
    $process.Id | Set-Content (Join-Path $dataDir 'service.pid')
    Write-Output ('Company website process started: ' + $process.Id)
} finally {
    Remove-Item Env:COMPANY_ADMIN_PASSWORD -ErrorAction SilentlyContinue
    $credential = $null
    $secure = $null
}
