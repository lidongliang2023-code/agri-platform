const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const channels={products:'产品频道',solutions:'解决方案',cases:'标杆案例',about:'关于我们',support:'服务支持',partners:'生态伙伴'};

let data=null;
let tab='dashboard';
let contentQuery='',contentState='all',page=1;
const pageSize=8;
let contentTag='',contentOrder='manual',leadQuery='',leadState='all',auditQuery='',auditAction='all';
let rbacOrgQuery='',rbacRoleQuery='',rbacUserQuery='',rbacUserOrg='';
let editorDirty=false,settingsDirty=false,leadDirty=false;

function hasPerm(code){
  if(!data||!data.user) return false;
  if(data.user.is_super) return true;
  return Array.isArray(data.user.permissions) && data.user.permissions.includes(code);
}

function parseMeta(r){
  if(r && typeof r.meta === 'object' && r.meta !== null) return r.meta;
  if(r && typeof r.meta === 'string'){
    try{ return JSON.parse(r.meta)||{} }catch{ return {} }
  }
  return {};
}

function publicationState(r){
  if(!r.published) return 'draft';
  try{
    const p=JSON.parse(r.published);
    const m1=parseMeta(r);
    const m2=p.meta||{};
    const metaDiff=JSON.stringify(Object.entries(m1).sort())!==JSON.stringify(Object.entries(m2).sort());
    return (['channel','title','summary','body','tag','sort'].some(k=>p[k]!==r[k]) || metaDiff)?'changed':'published';
  }catch{
    return 'changed';
  }
}

async function api(path,body){
  const r=await fetch(`./api/${path}`,{
    method:body?'POST':'GET',
    headers:body?{'Content-Type':'application/json','X-CSRF-Token':data?.csrf||''}:{},
    body:body?JSON.stringify(body):undefined
  });
  const j=await r.json().catch(()=>({}));
  if(!r.ok){
    if(r.status===401) login();
    throw Error(j.error||'请求处理失败');
  }
  return j;
}

function error(e){
  const m=$('#message');
  m.classList.remove('success');
  m.textContent=e.message||String(e);
}

function notify(text){
  const m=$('#message');
  m.classList.add('success');
  m.textContent=text;
}

function canLeave(){
  return !(settingsDirty||leadDirty||editorDirty)||confirm('有未保存的数据修改，确定放弃？');
}

async function load(){
  try{
    data=await api('admin');
    $('#logout').hidden=false;
    render();
  }catch(e){
    error(e);
  }
}

function login(){
  $('#logout').hidden=true;
  $('#app').innerHTML=`
  <div class="cms-login-card">
    <div class="login-brand-head">
      <span class="login-mark">禾</span>
      <h2>现代农业产业官网 · 内容运营中台</h2>
      <p class="muted">统一内容资产发布 · RBAC组织权限协同中枢</p>
    </div>
    <div class="login-mode-tabs">
      <button type="button" class="tab-btn active" id="btn-login-account">人员账号登录</button>
      <button type="button" class="tab-btn" id="btn-login-secret">管理密码登录</button>
    </div>
    <form class="login-form-inner" id="form-login-account">
      <label>用户名 / 员工账号
        <input name="username" required placeholder="如 admin / editor / service" autocomplete="username">
      </label>
      <label>登录密码
        <input name="password" type="password" required placeholder="默认 Admin@123" autocomplete="current-password">
      </label>
      <button class="btn green full-btn" type="submit">安全登录中台</button>
      <p class="login-hint">支持角色：超级管理员(admin)、内容主编(editor)、政企线索专员(service)、审计员(auditor)</p>
    </form>
    <form class="login-form-inner" id="form-login-secret" hidden>
      <label>部署管理密码
        <input name="password" type="password" required minlength="8" placeholder="部署时配置的超级管理密码" autocomplete="current-password">
      </label>
      <button class="btn green full-btn" type="submit">以超级管理员身份登录</button>
      <p class="login-hint">兼容独立部署单管理密码认证，直接赋予超级管理员全量权限。</p>
    </form>
  </div>`;

  const btnAcc=$('#btn-login-account');
  const btnSec=$('#btn-login-secret');
  const formAcc=$('#form-login-account');
  const formSec=$('#form-login-secret');

  btnAcc.onclick=()=>{
    btnAcc.classList.add('active');btnSec.classList.remove('active');
    formAcc.hidden=false;formSec.hidden=true;
  };
  btnSec.onclick=()=>{
    btnSec.classList.add('active');btnAcc.classList.remove('active');
    formSec.hidden=false;formAcc.hidden=true;
  };

  formAcc.onsubmit=async e=>{
    e.preventDefault();
    try{
      await api('login',Object.fromEntries(new FormData(e.target)));
      $('#message').textContent='';
      await load();
    }catch(err){ error(err); }
  };
  formSec.onsubmit=async e=>{
    e.preventDefault();
    try{
      await api('login',Object.fromEntries(new FormData(e.target)));
      $('#message').textContent='';
      await load();
    }catch(err){ error(err); }
  };
}

function render(){
  $('#message').textContent='';
  const user = data.user || {real_name:'管理员',username:'admin',is_super:true};

  const navGroups=[
    {
      group:'运营驾驶舱',
      items:[
        {key:'dashboard',label:'运营总览',perm:'dashboard:view',badge:null}
      ]
    },
    {
      group:'内容矩阵运营',
      items:[
        {key:'products',label:'产品频道',perm:'content:view',badge:data.records.filter(r=>r.channel==='products').length},
        {key:'solutions',label:'解决方案',perm:'content:view',badge:data.records.filter(r=>r.channel==='solutions').length},
        {key:'cases',label:'标杆案例',perm:'content:view',badge:data.records.filter(r=>r.channel==='cases').length},
        {key:'support',label:'服务支持',perm:'content:view',badge:data.records.filter(r=>r.channel==='support').length},
        {key:'partners',label:'生态伙伴',perm:'content:view',badge:data.records.filter(r=>r.channel==='partners').length},
        {key:'about',label:'关于我们',perm:'content:view',badge:data.records.filter(r=>r.channel==='about').length},
        {key:'management',label:'管理团队',perm:'content:view',badge:data.records.filter(r=>r.channel==='about'&&r.tag==='团队介绍').length}
      ]
    },
    {
      group:'业务协同与线索',
      items:[
        {key:'leads',label:'咨询线索',perm:'lead:view',badge:data.leads.filter(r=>r.status!=='已完成').length}
      ]
    },
    {
      group:'组织与权限体系(RBAC)',
      items:[
        {key:'rbac_org',label:'组织架构',perm:'rbac:org:view',badge:data.orgs?.length||0},
        {key:'rbac_role',label:'角色权限',perm:'rbac:role:view',badge:data.roles?.length||0},
        {key:'rbac_user',label:'人员账号',perm:'rbac:user:view',badge:data.users?.length||0}
      ]
    },
    {
      group:'系统与审计',
      items:[
        {key:'settings',label:'站点设置',perm:'settings:view',badge:null},
        {key:'audit',label:'操作审计',perm:'audit:view',badge:null}
      ]
    }
  ];

  const currentItem = navGroups.flatMap(g=>g.items).find(i=>i.key===tab) || {label:'工作台'};

  $('#app').innerHTML=`
  <div class="cms-framework">
    <aside class="cms-framework-sidebar">
      <div class="cms-sb-brand">
        <span class="sb-brand-mark">禾</span>
        <div class="sb-brand-info">
          <strong>公司官网 · 内容中台</strong>
          <small>AGRI-ENTERPRISE CMS</small>
        </div>
      </div>
      
      <div class="cms-sb-user-card">
        <div class="sb-user-avatar">${esc(user.real_name.slice(0,1))}</div>
        <div class="sb-user-details">
          <b>${esc(user.real_name)}</b>
          <span>@${esc(user.username)} · ${user.is_super?'超级管理员':'业务人员'}</span>
        </div>
      </div>

      <nav class="cms-sb-nav">
        ${navGroups.map(g=>{
          const visibleItems = g.items.filter(item=>hasPerm(item.perm));
          if(!visibleItems.length) return '';
          return `
          <div class="nav-group">
            <div class="nav-group-title">${esc(g.group)}</div>
            ${visibleItems.map(item=>`
              <button data-tab="${item.key}" class="nav-item-btn ${tab===item.key?'active':''}">
                <span>${esc(item.label)}</span>
                ${item.badge!==null?`<span class="nav-badge">${item.badge}</span>`:''}
              </button>
            `).join('')}
          </div>`;
        }).join('')}
      </nav>

      <div class="cms-sb-foot">
        <span class="sb-foot-dot"></span>
        <small>RBAC安全模型已挂载 · 会话加密保护</small>
      </div>
    </aside>

    <div class="cms-framework-body">
      <header class="cms-topbar">
        <div class="topbar-left">
          <span class="topbar-crumb">管理中枢 / ${esc(currentItem.label)}</span>
        </div>
        <div class="topbar-actions">
          <button class="topbar-btn" id="refresh-data"><span>↻</span> 刷新数据</button>
          <a class="topbar-btn highlight" href="./" target="_blank" rel="noopener">浏览官网前台 ↗</a>
        </div>
      </header>

      <main class="cms-framework-panel" id="panel"></main>
    </div>
  </div>`;

  document.querySelectorAll('[data-tab]').forEach(b=>{
    b.onclick=()=>{
      if(!canLeave()) return;
      settingsDirty=false;leadDirty=false;editorDirty=false;
      tab=b.dataset.tab;
      contentQuery='';contentState='all';contentTag='';page=1;
      render();
    };
  });

  $('#refresh-data').onclick=()=>{
    if(canLeave()){
      settingsDirty=false;leadDirty=false;editorDirty=false;
      load();
    }
  };

  if(tab==='dashboard') dashboard();
  else if(channels[tab]||tab==='management') content();
  else if(tab==='settings') settings();
  else if(tab==='leads') leads();
  else if(tab==='rbac_org') rbacOrg();
  else if(tab==='rbac_role') rbacRole();
  else if(tab==='rbac_user') rbacUser();
  else if(tab==='audit') auditPanel();
}

function dashboard(){
  const counts=[
    ['官网公开内容',data.records.filter(r=>r.published).length],
    ['待发草稿资产',data.records.filter(r=>publicationState(r)!=='published').length],
    ['待跟进客商需求',data.leads.filter(r=>r.status!=='已完成').length],
    ['组织机构数',data.orgs?.length||0],
    ['配置角色数',data.roles?.length||0],
    ['平台账号数',data.users?.length||0]
  ];

  $('#panel').innerHTML=`
  <div class="dash-welcome-card">
    <div class="dw-copy">
      <h2>欢迎进入现代农业产业互联网运营中台</h2>
      <p>统一全链路内容发布、管理团队核验、绿色供应链展示与组织权限体系（RBAC）。确保所有外发物料具备合规授权，所有角色拥有清晰权限边界。</p>
    </div>
    <div class="dw-actions">
      ${hasPerm('content:edit')?`<button class="btn green" id="dash-new-prod">＋ 录入产品/案例</button>`:''}
      ${hasPerm('rbac:user:manage')?`<button class="btn" id="dash-new-user">＋ 添加人员账号</button>`:''}
    </div>
  </div>

  <div class="dash-stat-grid">
    ${counts.map(([n,v])=>`
      <div class="stat-card">
        <span class="stat-num">${v}</span>
        <span class="stat-name">${n}</span>
      </div>
    `).join('')}
  </div>

  <div class="dash-split-row">
    <div class="dash-pane">
      <h3>各频道内容资产一览</h3>
      ${table(['频道名称','总草稿数','已正式发布','待发布修改'],Object.entries(channels).map(([k,v])=>{
        const rows=data.records.filter(r=>r.channel===k);
        return [v,rows.length,rows.filter(r=>r.published).length,rows.filter(r=>publicationState(r)!=='published').length];
      }))}
    </div>
    <div class="dash-pane">
      <h3>近期操作审计</h3>
      ${table(['操作动作','对象编号','执行人','记录时间'],data.audit.slice(0,6).map(r=>[r.action,r.object_id,r.operator||'system',r.created]))}
    </div>
  </div>`;

  if($('#dash-new-prod')){
    $('#dash-new-prod').onclick=()=>{
      tab='products';render();
      if($('#new')) $('#new').click();
    };
  }
  if($('#dash-new-user')){
    $('#dash-new-user').onclick=()=>{
      tab='rbac_user';render();
      if($('#new-user')) $('#new-user').click();
    };
  }
}

function table(head,rows){
  return `
  <div class="admin-table-box">
    <table>
      <thead><tr>${head.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead>
      <tbody>
        ${rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}
      </tbody>
    </table>
    ${rows.length?'':'<p class="empty-hint">暂无记录</p>'}
  </div>`;
}

function content(){
  const all=data.records.filter(r=>tab==='management'?(r.channel==='about'&&r.tag==='团队介绍'):r.channel===tab);
  const matched=all.filter(r=>{
    const m=parseMeta(r);
    const metaStr=Object.values(m).join(' ');
    const matchedState=(contentState==='all'||publicationState(r)===contentState);
    const matchedQuery=`${r.title} ${r.tag} ${r.summary} ${metaStr}`.toLowerCase().includes(contentQuery.toLowerCase());
    return matchedState && matchedQuery && (!contentTag || r.tag===contentTag);
  });

  matched.sort((a,b)=>contentOrder==='updated'?b.updated.localeCompare(a.updated):contentOrder==='title'?a.title.localeCompare(b.title,'zh-CN'):a.sort-b.sort||a.title.localeCompare(b.title,'zh-CN'));
  const totalPages=Math.max(1,Math.ceil(matched.length/pageSize));
  page=Math.min(page,totalPages);
  const records=matched.slice((page-1)*pageSize,page*pageSize);

  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>${tab==='management'?'管理团队':channels[tab]}内容列表</h2>
      <p class="muted">遵循草稿优先与审核发布机制；支持结构化参数编辑、富文本及多端预览。</p>
    </div>
    ${hasPerm('content:edit')?`<button class="btn green" id="new">＋ 新增内容草稿</button>`:''}
  </div>

  <div class="filter-toolbar">
    <input id="content-query" type="search" placeholder="搜索标题、摘要、分类、证书编号…" value="${esc(contentQuery)}">
    <select id="content-state">
      ${Object.entries({all:'全部发布状态',draft:'未公开草稿',changed:'有未发布修改',published:'已发布'}).map(([k,v])=>`<option value="${k}" ${contentState===k?'selected':''}>${v}</option>`).join('')}
    </select>
    <select id="content-tag">
      <option value="">全部分类标签</option>
      ${[...new Set(all.map(r=>r.tag).filter(Boolean))].map(v=>`<option ${contentTag===v?'selected':''} value="${esc(v)}">${esc(v)}</option>`).join('')}
    </select>
    <select id="content-order">
      ${Object.entries({manual:'运营排序权重',updated:'按更新时间排序',title:'按标题名称排序'}).map(([k,v])=>`<option value="${k}" ${contentOrder===k?'selected':''}>${v}</option>`).join('')}
    </select>
    <button class="btn" id="reset-filters">重置筛选</button>
  </div>

  <div class="content-cards-stream">
    ${records.map(r=>{
      const m=parseMeta(r);
      let pill='';
      if(r.channel==='products') pill=`${esc(m.badge||r.tag||'核心产品')} · ${esc(m.archLayer||'业务协同层')}`;
      else if(r.channel==='solutions') pill=`方案: ${esc(m.targetIndustry||r.tag||'现代农业')} · ${esc(m.deliveryCycle||'交付周期待定')}`;
      else if(r.channel==='cases') pill=`案例: ${esc(m.clientType||'农业主体')} · ${esc(m.caseScene||r.tag||'实景示范')}`;
      else if(r.tag==='团队介绍') pill=`${esc(m.teamType==='member'?'成员':m.teamType==='group'?'专业团队':'待补充')} · ${esc(m.department||'未归属部门')} · ${esc(m.role||'待设职责')}`;
      else if(r.tag==='发展历程'&&m.year) pill=`${esc(m.year)}${m.date?` (${esc(m.date)})`:''}${m.milestone==='1'?' · ★ 关键里程碑':''}`;
      else if(r.tag==='资质荣誉'&&(m.issuer||m.certNo)) pill=`${m.year?`${esc(m.year)} · `:''}${m.issuer?`发证: ${esc(m.issuer)}`:''}${m.certNo?` · 编号: ${esc(m.certNo)}`:''}`;

      const st=publicationState(r);
      const stMap={draft:['未公开草稿','tag-draft'],changed:['有未发布修改','tag-changed'],published:['已发布官网','tag-published']};

      return `
      <article class="content-item-card">
        <div class="cic-main">
          <div class="cic-title-line">
            <h3>${esc(r.title)}</h3>
            <span class="status-pill ${stMap[st][1]}">${stMap[st][0]}</span>
            ${pill?`<span class="meta-pill">${pill}</span>`:''}
          </div>
          <p class="cic-summary">${esc(r.summary)}</p>
          <div class="cic-foot-meta">
            <span>分类：<b>${esc(r.tag||'未分类')}</b></span>
            <span>排序权重：<b>${r.sort}</b></span>
            <span>版本：<b>v${r.revision}</b></span>
            <span>更新时间：<b>${esc(r.updated)}</b></span>
          </div>
        </div>
        <div class="cic-actions">
          ${hasPerm('content:edit')?`<button class="btn" data-edit="${r.id}">编辑草稿</button>`:''}
          ${hasPerm('content:edit')?`<button class="btn" data-copy="${r.id}">复制副本</button>`:''}
          <button class="btn" data-preview="${r.id}">全屏预览</button>
          ${r.published?`<a class="btn" href="./#/detail/${encodeURIComponent(r.id)}" target="_blank" rel="noopener">前台核验 ↗</a>`:''}
          ${hasPerm('content:publish')?`
            <button class="btn green" data-publish="${r.id}">发布到官网</button>
            ${r.published?`<button class="btn red" data-withdraw="${r.id}">撤回发布</button>`:''}
          `:''}
        </div>
      </article>`;
    }).join('')}
    ${records.length?'':'<div class="empty-stream"><p>暂无符合筛选的内容记录</p></div>'}
  </div>

  <div class="table-pager">
    <span>共 ${matched.length} 项记录 · 当前第 ${page} / ${totalPages} 页</span>
    <div class="pager-buttons">
      <button class="btn" id="prev-page" ${page===1?'disabled':''}>上一页</button>
      <button class="btn" id="next-page" ${page===totalPages?'disabled':''}>下一页</button>
    </div>
  </div>`;

  $('#prev-page').onclick=()=>{page--;content()};
  $('#next-page').onclick=()=>{page++;content()};

  $('#content-query').oninput=e=>{
    const pos=e.target.selectionStart;
    contentQuery=e.target.value;page=1;
    content();
    $('#content-query').focus();
    $('#content-query').setSelectionRange(pos,pos);
  };
  $('#content-state').onchange=e=>{contentState=e.target.value;page=1;content()};
  $('#content-tag').onchange=e=>{contentTag=e.target.value;page=1;content()};
  $('#content-order').onchange=e=>{contentOrder=e.target.value;page=1;content()};
  $('#reset-filters').onclick=()=>{contentQuery='';contentState='all';contentTag='';contentOrder='manual';page=1;content()};

  if($('#new')) $('#new').onclick=()=>edit({channel:tab==='management'?'about':tab,sort:0,tag:tab==='management'?'团队介绍':tab==='about'?'公司介绍':''});

  document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>{
    const r=data.records.find(r=>r.id===b.dataset.copy);
    edit({...r,id:undefined,revision:undefined,published:null,title:(r.title+'（副本）').slice(0,120)});
  });
  document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>edit(data.records.find(r=>r.id===b.dataset.edit)));

  document.querySelectorAll('[data-preview]').forEach(b=>b.onclick=()=>{
    const r=data.records.find(r=>r.id===b.dataset.preview);
    const m=parseMeta(r);
    $('#editor-body').innerHTML=`
    <div class="preview-modal-pane">
      <span class="preview-badge">草稿安全预览 · 校验中</span>
      <span class="eyebrow">${esc(r.tag)}</span>
      <h2>${esc(r.title)}</h2>
      ${(m.year||m.issuer||m.certNo)?`<div class="meta-preview-strip">${m.year?`<span>年份: ${esc(m.year)}</span>`:''}${m.issuer?`<span>机构: ${esc(m.issuer)}</span>`:''}${m.certNo?`<span>证书号: ${esc(m.certNo)}</span>`:''}</div>`:''}
      <p class="preview-summary">${esc(r.summary)}</p>
      <div class="preview-content-box">${esc(r.body)}</div>
    </div>`;
    editorDirty=false;
    $('#editor').showModal();
  });

  ['publish','withdraw'].forEach(action=>document.querySelectorAll(`[data-${action}]`).forEach(b=>b.onclick=async()=>{
    const r=data.records.find(r=>r.id===b.dataset[action]);
    if(!confirm(`${action==='publish'?'将草稿正式发布到官网前台':'从官网撤回该发布版本'}：\n${r.title}？`)) return;
    try{
      b.disabled=true;
      await api('admin/status',{id:r.id,revision:r.revision,action});
      await load();
      notify(action==='publish'?'内容已发布到官网前台':'内容已从官网撤回，草稿仍保留于中台');
    }catch(e){
      b.disabled=false;
      error(e);
    }
  }));
}

function edit(r){
  const m=parseMeta(r);
  $('#editor-body').innerHTML=`
  <div class="editor-header">
    <h2>${r.id?'编辑':'新增'}${channels[r.channel]||'内容'}</h2>
    <span class="editor-tag">${r.id?`ID: ${esc(r.id)}`:'待生成'}</span>
  </div>
  <form id="edit" class="admin-form-grid">
    <label class="col-8">标题名称<input name="title" required maxlength="120" value="${esc(r.title)}" placeholder="请输入规范标题"></label>
    <label class="col-4">所属栏目<select name="channel" id="edit-channel">${Object.entries(channels).map(([k,v])=>`<option value="${k}" ${r.channel===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <label class="col-8">分类标签<input name="tag" id="edit-tag" maxlength="60" value="${esc(r.tag)}" list="about-tag-options" placeholder="如 核心产品、生产数字化、团队介绍"></label>
    <datalist id="about-tag-options">${['公司介绍','服务理念','团队介绍','发展历程','资质荣誉','新闻与活动','技术伙伴','产业伙伴','共创计划'].map(v=>`<option value="${v}"></option>`).join('')}</datalist>
    <label class="col-4">排序权重 (越小越靠前)<input name="sort" type="number" value="${r.sort||0}"></label>

    <fieldset id="meta-products" class="meta-box col-12" hidden>
      <legend>产品矩阵属性（架构分层）</legend>
      <div class="meta-grid">
        <label>定位徽标<input name="meta_badge" maxlength="50" placeholder="例如：旗舰级平台" value="${esc(m.badge)}"></label>
        <label>架构分层<select name="meta_archLayer">
          <option value="">请选择架构分层</option>
          ${['生产与感知层','供应链协同层','数据要素与资讯层','质量追溯与实景层','绿色双碳与监管层'].map(l=>`<option value="${esc(l)}" ${m.archLayer===l?'selected':''}>${esc(l)}</option>`).join('')}
        </select></label>
        <label class="col-12">适配规模<input name="meta_targetScale" maxlength="120" placeholder="例如：大中型农业龙头企业 / 农业产业化联合体" value="${esc(m.targetScale)}"></label>
        <label class="col-12">核心亮点场景（换行分隔）<textarea name="meta_coreFeatures" maxlength="1000" rows="3">${esc(m.coreFeatures)}</textarea></label>
      </div>
    </fieldset>

    <fieldset id="meta-solutions" class="meta-box col-12" hidden>
      <legend>解决方案蓝图属性</legend>
      <div class="meta-grid">
        <label>适配行业<input name="meta_targetIndustry" maxlength="80" placeholder="例如：特色果品全产业链" value="${esc(m.targetIndustry)}"></label>
        <label>建议周期<input name="meta_deliveryCycle" maxlength="80" placeholder="例如：2-4 周敏捷接入" value="${esc(m.deliveryCycle)}"></label>
        <label class="col-12">行业痛点挑战（换行分隔）<textarea name="meta_painPoints" maxlength="1000" rows="3">${esc(m.painPoints)}</textarea></label>
        <label class="col-12">推荐产品套件（逗号分隔）<input name="meta_relatedProducts" maxlength="300" value="${esc(m.relatedProducts)}"></label>
      </div>
    </fieldset>

    <fieldset id="meta-cases" class="meta-box col-12" hidden>
      <legend>标杆案例实效属性</legend>
      <div class="meta-grid">
        <label>客户主体类型<input name="meta_clientType" maxlength="80" placeholder="例如：省级农业产业化龙头企业" value="${esc(m.clientType)}"></label>
        <label>落地业务场景<input name="meta_caseScene" maxlength="100" placeholder="例如：数字农业基地建设" value="${esc(m.caseScene)}"></label>
        <label class="col-12">核心实效证明（换行罗列，必须真实核验）<textarea name="meta_outcomes" maxlength="1500" rows="3">${esc(m.outcomes)}</textarea></label>
      </div>
    </fieldset>

    <fieldset id="meta-team" class="meta-box col-12" hidden>
      <legend>团队资料与授权合规</legend>
      <div class="meta-grid">
        <label>展示类型<select name="meta_teamType"><option value="">请选择</option><option value="member" ${m.teamType==='member'?'selected':''}>公司成员</option><option value="group" ${m.teamType==='group'?'selected':''}>专业团队</option></select></label>
        <label>岗位职责<input name="meta_role" maxlength="100" value="${esc(m.role)}"></label>
        <label>部门<input name="meta_department" maxlength="80" value="${esc(m.department)}"></label>
        <label>管理序列<select name="meta_teamCategory"><option value="">未分类</option>${Object.entries({board:'董事会',executive:'经营管理层',expert:'专家顾问',professional:'专业团队'}).map(([k,v])=>`<option value="${k}" ${m.teamCategory===k?'selected':''}>${v}</option>`).join('')}</select></label>
        <div class="col-12 portrait-uploader">
          <span>肖像图片</span>
          <input type="hidden" name="meta_portraitUrl" id="portrait-url" value="${esc(m.portraitUrl)}">
          <div class="portrait-box">
            <div id="portrait-preview" class="portrait-preview"></div>
            <div>
              <input type="file" id="portrait-file" accept="image/jpeg,image/png,image/webp" hidden>
              <button type="button" class="btn green" id="portrait-pick">上传肖像图片</button>
              <button type="button" class="btn" id="portrait-clear">清除图片</button>
              <p id="portrait-status" class="muted">仅支持 JPG/PNG/WEBP，≤2MB；个人需确认授权。</p>
            </div>
          </div>
        </div>
        <label class="col-12 check"><input type="checkbox" name="meta_publicConsent" value="1" ${m.publicConsent==='1'?'checked':''}> 已取得该成员姓名与履历对外展示授权</label>
      </div>
    </fieldset>

    <fieldset id="meta-history" class="meta-box col-12" hidden>
      <legend>发展历程专属属性</legend>
      <div class="meta-grid">
        <label>年份（如 2026）<input name="meta_year" maxlength="10" value="${esc(m.year)}"></label>
        <label>月份/日期（选填，如 2026-08）<input name="meta_date" maxlength="20" value="${esc(m.date)}"></label>
        <label class="col-12 check"><input type="checkbox" name="meta_milestone" value="1" ${m.milestone==='1'?'checked':''}> 设为重点里程碑节点（高亮展示）</label>
      </div>
    </fieldset>

    <fieldset id="meta-honor" class="meta-box col-12" hidden>
      <legend>资质荣誉专属属性</legend>
      <div class="meta-grid">
        <label>年份<input name="meta_honor_year" maxlength="10" value="${esc(m.year)}"></label>
        <label>颁发或认定机构<input name="meta_issuer" maxlength="120" value="${esc(m.issuer)}"></label>
        <label>证书编号<input name="meta_certNo" maxlength="100" value="${esc(m.certNo)}"></label>
        <label>有效期<input name="meta_validUntil" maxlength="50" value="${esc(m.validUntil)}"></label>
        <label class="col-12">官方核验地址 (HTTPS)<input name="meta_verifyUrl" maxlength="250" value="${esc(m.verifyUrl)}"></label>
      </div>
    </fieldset>

    <label class="col-12">摘要说明<textarea name="summary" required maxlength="500" rows="3">${esc(r.summary)}</textarea></label>
    <label class="col-12">正文详情（支持纯文本与段落换行）<textarea name="body" required maxlength="20000" rows="10">${esc(r.body)}</textarea></label>

    <div class="editor-actions-row col-12">
      <span class="editor-tip" id="save-hint">快捷键 Ctrl+S 保存草稿</span>
      <button class="btn green" type="submit">保存草稿到数据库</button>
    </div>
    <p id="edit-error" class="error-msg col-12" role="alert"></p>
  </form>`;

  const updateMetaBoxes=()=>{
    const curChannel=$('#edit-channel').value;
    const curTag=($('#edit-tag').value||'').trim();
    $('#meta-history').hidden=!(curChannel==='about'&&curTag==='发展历程');
    $('#meta-honor').hidden=!(curChannel==='about'&&curTag==='资质荣誉');
    $('#meta-team').hidden=!(curChannel==='about'&&curTag==='团队介绍');
    $('#meta-products').hidden=(curChannel!=='products');
    $('#meta-solutions').hidden=(curChannel!=='solutions');
    $('#meta-cases').hidden=(curChannel!=='cases');
  };

  $('#edit-tag').oninput=updateMetaBoxes;
  $('#edit-channel').onchange=updateMetaBoxes;
  updateMetaBoxes();

  const portraitUrl=$('#portrait-url'),portraitStatus=$('#portrait-status');
  const showPortrait=()=>{
    $('#portrait-preview').innerHTML=portraitUrl.value?`<img src="${esc(portraitUrl.value)}" alt="肖像预览">`:'<span>无肖像</span>';
    $('#portrait-clear').hidden=!portraitUrl.value;
  };
  showPortrait();

  $('#portrait-pick').onclick=()=>$('#portrait-file').click();
  $('#portrait-clear').onclick=()=>{portraitUrl.value='';showPortrait();editorDirty=true;};
  $('#portrait-file').onchange=async e=>{
    const file=e.target.files[0];e.target.value='';if(!file)return;
    const pick=$('#portrait-pick');pick.disabled=true;portraitStatus.textContent='正在上传图片…';
    try{
      const res=await fetch('./api/admin/upload',{method:'POST',headers:{'Content-Type':file.type,'X-CSRF-Token':data.csrf},body:file});
      const j=await res.json().catch(()=>({}));
      if(!res.ok) throw new Error(j.error||'上传失败');
      portraitUrl.value=j.url;showPortrait();editorDirty=true;
      portraitStatus.textContent='上传成功，请点击下方保存草稿。';
    }catch(err){ portraitStatus.textContent=err.message; }
    finally{ pick.disabled=false; }
  };

  editorDirty=false;
  $('#editor').showModal();

  const form=$('#edit');
  form.addEventListener('input',()=>{editorDirty=true;$('#save-hint').textContent='有未保存修改';});
  form.onsubmit=async e=>{
    e.preventDefault();
    try{
      const f=new FormData(e.target);
      const b=Object.fromEntries(f);
      b.sort=Number(b.sort);

      const meta={};
      if(b.channel==='about'&&b.tag==='发展历程'){
        if(b.meta_year) meta.year=b.meta_year.trim();
        if(b.meta_date) meta.date=b.meta_date.trim();
        if(f.get('meta_milestone')) meta.milestone='1';
      }else if(b.channel==='about'&&b.tag==='团队介绍'){
        for(const key of ['teamType','role','department','expertise','serviceScope','publicConsent','teamCategory','englishName','portraitUrl']){
          const v=String(f.get('meta_'+key)||'').trim(); if(v) meta[key]=v;
        }
      }else if(b.channel==='about'&&b.tag==='资质荣誉'){
        if(b.meta_honor_year) meta.year=b.meta_honor_year.trim();
        if(b.meta_issuer) meta.issuer=b.meta_issuer.trim();
        if(b.meta_certNo) meta.certNo=b.meta_certNo.trim();
        if(b.meta_validUntil) meta.validUntil=b.meta_validUntil.trim();
        if(b.meta_verifyUrl) meta.verifyUrl=b.meta_verifyUrl.trim();
      }else if(b.channel==='products'){
        for(const k of ['badge','archLayer','targetScale','coreFeatures']){
          const val=String(f.get('meta_'+k)||'').trim(); if(val) meta[k]=val;
        }
      }else if(b.channel==='solutions'){
        for(const k of ['targetIndustry','deliveryCycle','painPoints','relatedProducts']){
          const val=String(f.get('meta_'+k)||'').trim(); if(val) meta[k]=val;
        }
      }else if(b.channel==='cases'){
        for(const k of ['clientType','caseScene','outcomes']){
          const val=String(f.get('meta_'+k)||'').trim(); if(val) meta[k]=val;
        }
      }

      for(const k of Object.keys(b)) if(k.startsWith('meta_')) delete b[k];
      b.tag=b.tag.trim();
      b.meta=meta;

      const submit=e.target.querySelector('[type=submit]');
      submit.disabled=true;
      await api('admin/content',{...b,id:r.id,revision:r.revision});
      editorDirty=false;
      $('#editor').close();
      await load();
      notify('草稿已安全写入数据库；前台官网保留原发布内容。');
    }catch(err){
      $('#edit-error').textContent=err.message;
      const submit=$('#edit [type=submit]');
      if(submit) submit.disabled=false;
    }
  };
}

function rbacOrg(){
  const orgs = (data.orgs||[]).filter(o=>!rbacOrgQuery||o.name.includes(rbacOrgQuery)||o.code.includes(rbacOrgQuery));
  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>组织架构管理</h2>
      <p class="muted">维护农业产业互联网部门层级、机构编码及责任负责人，支撑数据隔离与权限流转。</p>
    </div>
    ${hasPerm('rbac:org:manage')?`<button class="btn green" id="new-org">＋ 新增组织部门</button>`:''}
  </div>

  <div class="filter-toolbar">
    <input id="rbac-org-q" type="search" placeholder="搜索机构名称或编码…" value="${esc(rbacOrgQuery)}">
    <span>共 ${orgs.length} 个组织机构</span>
  </div>

  <div class="admin-table-box">
    <table>
      <thead>
        <tr>
          <th>组织名称</th>
          <th>组织编码</th>
          <th>上级组织</th>
          <th>负责人</th>
          <th>排序</th>
          <th>状态</th>
          <th>创建时间</th>
          ${hasPerm('rbac:org:manage')?'<th>操作</th>':''}
        </tr>
      </thead>
      <tbody>
        ${orgs.map(o=>{
          const parent = data.orgs.find(p=>p.id===o.parent_id);
          return `
          <tr>
            <td><b>${esc(o.name)}</b></td>
            <td><code>${esc(o.code)}</code></td>
            <td>${parent?esc(parent.name):'<span class="muted">顶级组织</span>'}</td>
            <td>${esc(o.leader||'—')}</td>
            <td>${o.sort}</td>
            <td><span class="status-pill ${o.status==='active'?'tag-published':'tag-draft'}">${o.status==='active'?'正常运行':'已停用'}</span></td>
            <td>${esc(o.created)}</td>
            ${hasPerm('rbac:org:manage')?`
              <td>
                <button class="btn sm" data-edit-org="${esc(o.id)}">编辑</button>
                <button class="btn sm red" data-del-org="${esc(o.id)}">删除</button>
              </td>
            `:''}
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    ${orgs.length?'':'<p class="empty-hint">暂无组织架构信息</p>'}
  </div>`;

  $('#rbac-org-q').oninput=e=>{rbacOrgQuery=e.target.value;rbacOrg()};
  if($('#new-org')) $('#new-org').onclick=()=>editOrg({});
  document.querySelectorAll('[data-edit-org]').forEach(b=>b.onclick=()=>editOrg(data.orgs.find(o=>o.id===b.dataset.editOrg)));
  document.querySelectorAll('[data-del-org]').forEach(b=>b.onclick=async()=>{
    const o=data.orgs.find(o=>o.id===b.dataset.delOrg);
    if(!confirm(`确认删除组织架构【${o.name}】？`)) return;
    try{
      await api('admin/rbac/org',{action:'delete',id:o.id});
      await load();
      notify('组织架构已删除');
    }catch(err){ error(err); }
  });
}

function editOrg(o){
  $('#editor-body').innerHTML=`
  <div class="editor-header">
    <h2>${o.id?'编辑组织架构':'新增组织部门'}</h2>
    <span class="editor-tag">${o.id||'新机构'}</span>
  </div>
  <form id="form-org" class="admin-form-grid">
    <label class="col-8">组织名称<input name="name" required maxlength="80" value="${esc(o.name)}" placeholder="如 供应链金融部 / 设施农业运营中心"></label>
    <label class="col-4">组织编码<input name="code" required maxlength="40" value="${esc(o.code)}" placeholder="如 OPS_FIN" ${o.id?'readonly':''}></label>
    <label class="col-6">上级组织
      <select name="parent_id">
        <option value="">顶级组织（无上级）</option>
        ${(data.orgs||[]).filter(p=>p.id!==o.id).map(p=>`<option value="${esc(p.id)}" ${o.parent_id===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}
      </select>
    </label>
    <label class="col-6">部门负责人<input name="leader" maxlength="60" value="${esc(o.leader)}" placeholder="如 李总监"></label>
    <label class="col-6">排序权重<input name="sort" type="number" value="${o.sort||0}"></label>
    <label class="col-6">运行状态
      <select name="status">
        <option value="active" ${o.status!=='disabled'?'selected':''}>正常启用</option>
        <option value="disabled" ${o.status==='disabled'?'selected':''}>暂停使用</option>
      </select>
    </label>
    <div class="editor-actions-row col-12">
      <button class="btn green" type="submit">保存组织架构</button>
    </div>
    <p id="org-error" class="error-msg col-12"></p>
  </form>`;
  $('#editor').showModal();
  $('#form-org').onsubmit=async e=>{
    e.preventDefault();
    try{
      const b=Object.fromEntries(new FormData(e.target));
      b.sort=Number(b.sort);
      await api('admin/rbac/org',{...b,id:o.id});
      $('#editor').close();
      await load();
      notify('组织架构已保存');
    }catch(err){ $('#org-error').textContent=err.message; }
  };
}

function rbacRole(){
  const roles = (data.roles||[]).filter(r=>!rbacRoleQuery||r.name.includes(rbacRoleQuery)||r.code.includes(rbacRoleQuery));
  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>角色与权限管理 (RBAC)</h2>
      <p class="muted">通过角色组装功能权限，实现基于职能的细粒度操作隔离。</p>
    </div>
    ${hasPerm('rbac:role:manage')?`<button class="btn green" id="new-role">＋ 新增管理角色</button>`:''}
  </div>

  <div class="filter-toolbar">
    <input id="rbac-role-q" type="search" placeholder="搜索角色名称或编码…" value="${esc(rbacRoleQuery)}">
    <span>共 ${roles.length} 个角色定义</span>
  </div>

  <div class="admin-table-box">
    <table>
      <thead>
        <tr>
          <th>角色名称</th>
          <th>角色编码</th>
          <th>角色说明</th>
          <th>拥有权限数</th>
          <th>排序</th>
          <th>状态</th>
          <th>创建时间</th>
          ${hasPerm('rbac:role:manage')?'<th>操作</th>':''}
        </tr>
      </thead>
      <tbody>
        ${roles.map(r=>`
          <tr>
            <td><b>${esc(r.name)}</b></td>
            <td><code>${esc(r.code)}</code></td>
            <td>${esc(r.description||'—')}</td>
            <td><span class="meta-pill">${r.permissions?.length||0} 个权限点</span></td>
            <td>${r.sort}</td>
            <td><span class="status-pill ${r.status==='active'?'tag-published':'tag-draft'}">${r.status==='active'?'启用':'停用'}</span></td>
            <td>${esc(r.created)}</td>
            ${hasPerm('rbac:role:manage')?`
              <td>
                <button class="btn sm" data-edit-role="${esc(r.id)}">配置权限</button>
                ${r.id!=='role-super'?`<button class="btn sm red" data-del-role="${esc(r.id)}">删除</button>`:''}
              </td>
            `:''}
          </tr>
        `).join('')}
      </tbody>
    </table>
    ${roles.length?'':'<p class="empty-hint">暂无角色定义</p>'}
  </div>`;

  $('#rbac-role-q').oninput=e=>{rbacRoleQuery=e.target.value;rbacRole()};
  if($('#new-role')) $('#new-role').onclick=()=>editRole({});
  document.querySelectorAll('[data-edit-role]').forEach(b=>b.onclick=()=>editRole(data.roles.find(r=>r.id===b.dataset.editRole)));
  document.querySelectorAll('[data-del-role]').forEach(b=>b.onclick=async()=>{
    const r=data.roles.find(r=>r.id===b.dataset.delRole);
    if(!confirm(`确认删除角色【${r.name}】？关联用户的该角色绑定将被自动解除。`)) return;
    try{
      await api('admin/rbac/role',{action:'delete',id:r.id});
      await load();
      notify('角色已成功删除');
    }catch(err){ error(err); }
  });
}

function editRole(r){
  const assigned = new Set(r.permissions||[]);
  const permsByModule = {};
  (data.permissions||[]).forEach(p=>{
    permsByModule[p.module]=permsByModule[p.module]||[];
    permsByModule[p.module].push(p);
  });
  const moduleNames={dashboard:'控制台与概览',content:'内容资产与发布',leads:'客户咨询与线索',settings:'站点与基础配置',rbac:'组织与权限体系',audit:'安全与操作审计'};

  $('#editor-body').innerHTML=`
  <div class="editor-header">
    <h2>${r.id?'配置角色权限':'新增管理角色'}</h2>
    <span class="editor-tag">${r.id||'新角色'}</span>
  </div>
  <form id="form-role" class="admin-form-grid">
    <label class="col-6">角色名称<input name="name" required maxlength="80" value="${esc(r.name)}" placeholder="如 营销总监 / 采编审核员"></label>
    <label class="col-6">角色标识编码<input name="code" required maxlength="40" value="${esc(r.code)}" placeholder="如 content_reviewer" ${r.id==='role-super'?'readonly':''}></label>
    <label class="col-12">角色职责描述<textarea name="description" maxlength="200" rows="2">${esc(r.description)}</textarea></label>
    <label class="col-6">排序权重<input name="sort" type="number" value="${r.sort||0}"></label>
    <label class="col-6">运行状态
      <select name="status">
        <option value="active" ${r.status!=='disabled'?'selected':''}>启用</option>
        <option value="disabled" ${r.status==='disabled'?'selected':''}>停用</option>
      </select>
    </label>

    <div class="col-12 perm-assign-box">
      <div class="perm-assign-head">
        <strong>分配功能权限点</strong>
        <div>
          <button type="button" class="btn sm" id="perm-select-all">全选权限</button>
          <button type="button" class="btn sm" id="perm-clear-all">清空权限</button>
        </div>
      </div>
      <div class="perm-module-grid">
        ${Object.entries(permsByModule).map(([mod,list])=>`
          <div class="perm-mod-group">
            <div class="perm-mod-title">${esc(moduleNames[mod]||mod)}</div>
            <div class="perm-items">
              ${list.map(p=>`
                <label class="perm-checkbox-item">
                  <input type="checkbox" name="perm" value="${esc(p.code)}" ${assigned.has(p.code)?'checked':''}>
                  <div>
                    <b>${esc(p.name)}</b>
                    <small>${esc(p.description)}</small>
                  </div>
                </label>
              `).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="editor-actions-row col-12">
      <button class="btn green" type="submit">保存角色权限配置</button>
    </div>
    <p id="role-error" class="error-msg col-12"></p>
  </form>`;

  $('#perm-select-all').onclick=()=>{
    document.querySelectorAll('#form-role input[name="perm"]').forEach(cb=>cb.checked=true);
  };
  $('#perm-clear-all').onclick=()=>{
    document.querySelectorAll('#form-role input[name="perm"]').forEach(cb=>cb.checked=false);
  };

  $('#editor').showModal();
  $('#form-role').onsubmit=async e=>{
    e.preventDefault();
    try{
      const f=new FormData(e.target);
      const b=Object.fromEntries(f);
      b.sort=Number(b.sort);
      b.permissions=f.getAll('perm');
      await api('admin/rbac/role',{...b,id:r.id});
      $('#editor').close();
      await load();
      notify('角色权限配置已生效');
    }catch(err){ $('#role-error').textContent=err.message; }
  };
}

function rbacUser(){
  const users = (data.users||[]).filter(u=>{
    const matchQ=!rbacUserQuery||u.username.includes(rbacUserQuery)||u.real_name.includes(rbacUserQuery)||u.email.includes(rbacUserQuery);
    const matchOrg=!rbacUserOrg||u.org_id===rbacUserOrg;
    return matchQ&&matchOrg;
  });

  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>人员账号管理 (User Accounts)</h2>
      <p class="muted">管理运营人员账号、关联组织机构与绑定权限角色，支持启停与安全改密。</p>
    </div>
    ${hasPerm('rbac:user:manage')?`<button class="btn green" id="new-user">＋ 新增人员账号</button>`:''}
  </div>

  <div class="filter-toolbar">
    <input id="rbac-user-q" type="search" placeholder="搜索用户名、姓名或邮箱…" value="${esc(rbacUserQuery)}">
    <select id="rbac-user-org">
      <option value="">全部所属部门</option>
      ${(data.orgs||[]).map(o=>`<option value="${esc(o.id)}" ${rbacUserOrg===o.id?'selected':''}>${esc(o.name)}</option>`).join('')}
    </select>
    <span>共 ${users.length} 个账号</span>
  </div>

  <div class="admin-table-box">
    <table>
      <thead>
        <tr>
          <th>登录账号</th>
          <th>真实姓名</th>
          <th>归属组织</th>
          <th>分配角色</th>
          <th>联系方式</th>
          <th>账号状态</th>
          <th>更新时间</th>
          ${hasPerm('rbac:user:manage')?'<th>操作</th>':''}
        </tr>
      </thead>
      <tbody>
        ${users.map(u=>{
          const roleNames = (u.roles||[]).map(rid=>{
            const r=data.roles.find(x=>x.id===rid);
            return r?r.name:rid;
          });
          return `
          <tr>
            <td><code>${esc(u.username)}</code></td>
            <td><b>${esc(u.real_name)}</b></td>
            <td>${esc(u.org_name||'未归属')}</td>
            <td>${roleNames.length?roleNames.map(rn=>`<span class="meta-pill">${esc(rn)}</span>`).join(' '):'<span class="muted">未绑定</span>'}</td>
            <td><small>${esc(u.phone||'—')}<br>${esc(u.email||'')}</small></td>
            <td><span class="status-pill ${u.status==='active'?'tag-published':'tag-draft'}">${u.status==='active'?'正常运行':'已停用'}</span></td>
            <td>${esc(u.updated)}</td>
            ${hasPerm('rbac:user:manage')?`
              <td>
                <button class="btn sm" data-edit-user="${esc(u.id)}">编辑/改密</button>
                <button class="btn sm ${u.status==='active'?'':'green'}" data-toggle-user="${esc(u.id)}">${u.status==='active'?'停用':'启用'}</button>
                <button class="btn sm red" data-del-user="${esc(u.id)}">删除</button>
              </td>
            `:''}
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    ${users.length?'':'<p class="empty-hint">暂无符合条件的人员账号</p>'}
  </div>`;

  $('#rbac-user-q').oninput=e=>{rbacUserQuery=e.target.value;rbacUser()};
  $('#rbac-user-org').onchange=e=>{rbacUserOrg=e.target.value;rbacUser()};
  if($('#new-user')) $('#new-user').onclick=()=>editUser({});

  document.querySelectorAll('[data-edit-user]').forEach(b=>b.onclick=()=>editUser(data.users.find(u=>u.id===b.dataset.editUser)));
  document.querySelectorAll('[data-toggle-user]').forEach(b=>b.onclick=async()=>{
    const u=data.users.find(u=>u.id===b.dataset.toggleUser);
    const nextSt = u.status==='active'?'disabled':'active';
    try{
      await api('admin/rbac/user',{action:'status',id:u.id,status:nextSt});
      await load();
      notify(`账号【${u.username}】已${nextSt==='active'?'重新启用':'停用'}`);
    }catch(err){ error(err); }
  });

  document.querySelectorAll('[data-del-user]').forEach(b=>b.onclick=async()=>{
    const u=data.users.find(u=>u.id===b.dataset.delUser);
    if(!confirm(`确认彻底删除人员账号【${u.username} (${u.real_name})】？`)) return;
    try{
      await api('admin/rbac/user',{action:'delete',id:u.id});
      await load();
      notify('人员账号已删除');
    }catch(err){ error(err); }
  });
}

function editUser(u){
  const userRoles = new Set(u.roles||[]);
  $('#editor-body').innerHTML=`
  <div class="editor-header">
    <h2>${u.id?'编辑人员账号与权限':'新增人员账号'}</h2>
    <span class="editor-tag">${u.id||'新账号'}</span>
  </div>
  <form id="form-user" class="admin-form-grid">
    <label class="col-6">登录用户名<input name="username" required maxlength="40" value="${esc(u.username)}" placeholder="如 editor01" ${u.id?'readonly':''}></label>
    <label class="col-6">真实姓名<input name="real_name" required maxlength="60" value="${esc(u.real_name)}" placeholder="如 张三"></label>
    <label class="col-6">所属组织部门
      <select name="org_id">
        <option value="">未分配部门</option>
        ${(data.orgs||[]).map(o=>`<option value="${esc(o.id)}" ${u.org_id===o.id?'selected':''}>${esc(o.name)}</option>`).join('')}
      </select>
    </label>
    <label class="col-6">账号状态
      <select name="status">
        <option value="active" ${u.status!=='disabled'?'selected':''}>正常可用</option>
        <option value="disabled" ${u.status==='disabled'?'selected':''}>已停用</option>
      </select>
    </label>
    <label class="col-6">登录密码 ${u.id?'<small class="muted">(不修改请留空)</small>':''}
      <input name="password" type="password" minlength="8" placeholder="${u.id?'留空则维持原密码':'默认初始密码 Admin@123'}">
    </label>
    <label class="col-6">工作邮箱<input name="email" type="email" maxlength="100" value="${esc(u.email)}" placeholder="user@agri-tech.com"></label>
    <label class="col-12">联系电话<input name="phone" maxlength="30" value="${esc(u.phone)}" placeholder="如 13800000000"></label>

    <div class="col-12 perm-assign-box">
      <div class="perm-assign-head">
        <strong>赋予管理角色 (多选)</strong>
      </div>
      <div class="role-checkbox-stream">
        ${(data.roles||[]).map(r=>`
          <label class="role-chip-label">
            <input type="checkbox" name="role_id" value="${esc(r.id)}" ${userRoles.has(r.id)?'checked':''}>
            <span><b>${esc(r.name)}</b> <small>(${esc(r.code)})</small></span>
          </label>
        `).join('')}
      </div>
    </div>

    <div class="editor-actions-row col-12">
      <button class="btn green" type="submit">保存人员账号与角色</button>
    </div>
    <p id="user-error" class="error-msg col-12"></p>
  </form>`;

  $('#editor').showModal();
  $('#form-user').onsubmit=async e=>{
    e.preventDefault();
    try{
      const f=new FormData(e.target);
      const b=Object.fromEntries(f);
      b.roles=f.getAll('role_id');
      await api('admin/rbac/user',{...b,id:u.id});
      $('#editor').close();
      await load();
      notify('人员账号与角色关系已保存落库');
    }catch(err){ $('#user-error').textContent=err.message; }
  };
}

function settings(){
  const labels={brand:'品牌名称',company:'公司法定名称',slogan:'首页主标题',intro:'公司一句话介绍',email:'公开邮箱',phone:'公开联系电话',address:'公开地址',filing:'备案信息',portalUrl:'产品门户 HTTPS 地址（选填）'};
  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>公共站点配置与备案</h2>
      <p class="muted">维护全站品牌标牌、对外联络方式及业务门户单点入口。</p>
    </div>
  </div>
  <form id="settings" class="admin-form-grid">
    ${Object.entries(labels).map(([k,v])=>`
      <label class="${k==='intro'||k==='address'?'col-12':'col-6'}">${v}
        <input name="${k}" value="${esc(data.settings[k])}" maxlength="2000" ${k==='brand'||k==='slogan'?'required':''}>
      </label>
    `).join('')}
    ${hasPerm('settings:edit')?`
      <div class="editor-actions-row col-12">
        <button class="btn" type="submit" name="mode" value="draft">仅保存配置草稿</button>
        <button class="btn green" type="submit" name="mode" value="publish">保存并发布站点配置</button>
      </div>
    `:''}
  </form>`;

  $('#settings').addEventListener('input',()=>{settingsDirty=true;});
  $('#settings').onsubmit=async e=>{
    e.preventDefault();
    const publish=e.submitter.value==='publish';
    if(publish&&!confirm('将当前站点设置发布到公司官网？')) return;
    try{
      e.target.querySelectorAll('button').forEach(b=>b.disabled=true);
      await api('admin/settings',{...Object.fromEntries(new FormData(e.target)),revision:data.settingsRevision,publish});
      settingsDirty=false;await load();
      notify(publish?'站点设置已发布':'站点设置草稿已保存');
    }catch(err){
      e.target.querySelectorAll('button').forEach(b=>b.disabled=false);
      error(err);
    }
  };
}

function leads(){
  const matched = data.leads.filter(matchLead);
  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>政企合作与在线咨询线索</h2>
      <p class="muted">处理来自官网前台的预约咨询、基地实景看货、碳核算及数字农业建设需求。</p>
    </div>
  </div>
  <div class="filter-toolbar">
    <input id="lead-query" type="search" placeholder="搜索姓名、联系方式、需求与跟进备注…" value="${esc(leadQuery)}">
    <select id="lead-state">
      ${['all','待联系','跟进中','已完成'].map(v=>`<option value="${v}" ${leadState===v?'selected':''}>${v==='all'?'全部跟进状态':v}</option>`).join('')}
    </select>
    <span>显示 ${matched.length} / ${data.leads.length} 条</span>
  </div>
  <div class="lead-cards-grid">
    ${matched.map(r=>`
      <article class="lead-pro-card">
        <div class="lpc-head">
          <div>
            <h3>${esc(r.name)}</h3>
            <span class="lpc-contact">📞 ${esc(r.contact)}</span>
          </div>
          <span class="status-pill ${r.status==='待联系'?'tag-draft':r.status==='跟进中'?'tag-changed':'tag-published'}">${esc(r.status)}</span>
        </div>
        <div class="lpc-need">
          <b>客户需求诉求：</b>
          <p>${esc(r.need)}</p>
        </div>
        <div class="lpc-time">提交时间：${esc(r.created)}</div>
        ${hasPerm('lead:manage')?`
          <form data-lead="${esc(r.id)}" class="lead-action-form">
            <label>流转状态
              <select name="status">
                ${['待联系','跟进中','已完成'].map(v=>`<option ${r.status===v?'selected':''}>${v}</option>`).join('')}
              </select>
            </label>
            <label>跟进沟通纪要
              <textarea name="note" maxlength="2000" rows="3" placeholder="录入跟进情况与对接责任人…">${esc(r.note)}</textarea>
            </label>
            <button class="btn green sm">更新跟进状态</button>
            <span class="lead-fb" role="status"></span>
          </form>
        `:`
          <div class="lpc-note-readonly">
            <b>跟进记录：</b>
            <p>${esc(r.note||'暂无跟进备注')}</p>
          </div>
        `}
      </article>
    `).join('')}
    ${matched.length?'':'<p class="empty-hint">暂无符合条件的咨询线索</p>'}
  </div>`;

  $('#lead-query').onchange=e=>{if(!canLeave())return;leadDirty=false;leadQuery=e.target.value;leads()};
  $('#lead-state').onchange=e=>{if(!canLeave())return;leadDirty=false;leadState=e.target.value;leads()};

  document.querySelectorAll('[data-lead]').forEach(f=>{
    f.addEventListener('input',()=>{leadDirty=true;f.dataset.dirty='1';});
    f.onsubmit=async e=>{
      e.preventDefault();
      const b=f.querySelector('button');b.disabled=true;
      try{
        await api('admin/lead',{id:f.dataset.lead,...Object.fromEntries(new FormData(f))});
        leadDirty=false;await load();
        notify('咨询跟进记录已落库');
      }catch(err){
        f.querySelector('.lead-fb').textContent=err.message;
        b.disabled=false;
      }
    };
  });
}

function matchLead(r){
  return (leadState==='all'||r.status===leadState)&&[r.name,r.contact,r.need,r.note].join(' ').toLowerCase().includes(leadQuery.toLowerCase());
}

function auditPanel(){
  const rows=data.audit.filter(r=>(auditAction==='all'||r.action===auditAction)&&[r.action,r.object_id,r.operator||'',r.created].join(' ').toLowerCase().includes(auditQuery.toLowerCase()));
  $('#panel').innerHTML=`
  <div class="panel-header">
    <div>
      <h2>安全与操作审计日志</h2>
      <p class="muted">全量记录平台关键操作动作、对象编号与具体执行人员，防篡改追溯留痕。</p>
    </div>
  </div>
  <div class="filter-toolbar">
    <input id="audit-query" type="search" placeholder="搜索动作、对象ID、执行人员或时间…" value="${esc(auditQuery)}">
    <select id="audit-action">
      <option value="all">全量操作类型</option>
      ${[...new Set(data.audit.map(r=>r.action))].map(v=>`<option ${auditAction===v?'selected':''} value="${esc(v)}">${esc(v)}</option>`).join('')}
    </select>
    <span>匹配 ${rows.length} 条记录</span>
  </div>
  ${table(['操作动作','对象编号','执行人账号','记录时间'],rows.map(r=>[r.action,r.object_id,r.operator||'system',r.created]))}`;

  $('#audit-query').onchange=e=>{auditQuery=e.target.value;auditPanel()};
  $('#audit-action').onchange=e=>{auditAction=e.target.value;auditPanel()};
}

function closeEditor(){
  if(editorDirty&&!confirm('草稿修改尚未写入数据库，确定放弃？')) return;
  editorDirty=false;$('#editor').close();
}
$('#close').onclick=closeEditor;
$('#editor').addEventListener('cancel',e=>{e.preventDefault();closeEditor();});
window.addEventListener('beforeunload',e=>{if(editorDirty||settingsDirty||leadDirty){e.preventDefault();e.returnValue='';}});
document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'&&$('#editor').open&&$('#edit')){
    e.preventDefault();
    if(!$('#edit [type=submit]').disabled) $('#edit').requestSubmit();
  }
});

$('#logout').onclick=async()=>{
  try{
    if(!canLeave()) return;
    await api('logout',{});
    settingsDirty=false;leadDirty=false;editorDirty=false;
    data=null;
    login();
  }catch(e){ error(e); }
};

load();
