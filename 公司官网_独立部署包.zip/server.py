import os, json, sqlite3, secrets, hashlib, hmac, time, re, threading
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from http.cookies import SimpleCookie
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('COMPANY_DATA_DIR', str(ROOT / 'data')))
DATA.mkdir(parents=True, exist_ok=True)
DB = DATA / 'company.db'
UPLOADS = DATA / 'uploads'
UPLOAD_MAX = 2 * 1024 * 1024
UPLOAD_TYPES = {'.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp'}
UPLOAD_NAME = re.compile(r'[a-f0-9]{32}\.(jpg|png|webp)')
SESSIONS = {}
LIMITS = {}
LOCK = threading.Lock()
CHANNELS = {'products', 'solutions', 'cases', 'about', 'support', 'partners'}

def connect():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    return c

def hash_pw(password, salt=None):
    salt = salt or secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    return f"{salt}${hashed}"

def verify_pw(password, hashed_value):
    try:
        salt, hashed = hashed_value.split('$', 1)
        calc = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
        return hmac.compare_digest(calc, hashed)
    except Exception:
        return False

PERM_DEFS = [
    ("dashboard:view", "控制台概览", "查看控制台运行概况与统计指标", "dashboard"),
    ("content:view", "查看内容", "查看内容列表、草稿与详情", "content"),
    ("content:edit", "编辑内容", "新增、编辑并保存内容草稿", "content"),
    ("content:publish", "发布/撤回", "将草稿正式发布到官网或从官网撤回", "content"),
    ("content:upload", "上传素材", "上传肖像与媒体资源", "content"),
    ("lead:view", "查看咨询线索", "查看访客需求与跟进记录", "leads"),
    ("lead:manage", "处置线索", "流转咨询状态与录入跟进备注", "leads"),
    ("settings:view", "查看站点配置", "查看品牌与公共站点设置", "settings"),
    ("settings:edit", "配置站点", "修改站点草稿与发布站点配置", "settings"),
    ("rbac:org:view", "查看组织架构", "查看部门与组织层级", "rbac"),
    ("rbac:org:manage", "管理组织架构", "新增、编辑与调整组织机构", "rbac"),
    ("rbac:role:view", "查看角色权限", "查看角色列表与其配置的权限集", "rbac"),
    ("rbac:role:manage", "管理角色权限", "新增、编辑角色并分配权限点", "rbac"),
    ("rbac:user:view", "查看用户列表", "查看运营后台人员账号", "rbac"),
    ("rbac:user:manage", "管理用户账号", "新增、编辑账号与角色组织归属", "rbac"),
    ("audit:view", "查看操作审计", "查看平台所有关键操作记录", "audit"),
]

def initialize():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS content(
            id TEXT PRIMARY KEY,
            channel TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            body TEXT NOT NULL,
            tag TEXT NOT NULL,
            sort INTEGER NOT NULL DEFAULT 0,
            revision INTEGER NOT NULL DEFAULT 1,
            published TEXT,
            updated TEXT NOT NULL,
            meta TEXT DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS settings(
            id INTEGER PRIMARY KEY,
            draft TEXT NOT NULL,
            published TEXT,
            revision INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS leads(
            id TEXT PRIMARY KEY,
            name TEXT,
            contact TEXT,
            need TEXT,
            status TEXT,
            created TEXT,
            note TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS audit(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT,
            object_id TEXT,
            created TEXT,
            operator TEXT DEFAULT 'system'
        );
        CREATE TABLE IF NOT EXISTS sys_org (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            code TEXT NOT NULL UNIQUE,
            parent_id TEXT,
            sort INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'active',
            leader TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sys_perm (
            code TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            module TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sys_role (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            code TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            sort INTEGER NOT NULL DEFAULT 0,
            created TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sys_role_perm (
            role_id TEXT NOT NULL,
            perm_code TEXT NOT NULL,
            PRIMARY KEY (role_id, perm_code)
        );
        CREATE TABLE IF NOT EXISTS sys_user (
            id TEXT PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            real_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            org_id TEXT,
            email TEXT NOT NULL DEFAULT '',
            phone TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            created TEXT NOT NULL,
            updated TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sys_user_role (
            user_id TEXT NOT NULL,
            role_id TEXT NOT NULL,
            PRIMARY KEY (user_id, role_id)
        );
        ''')
        # 兼容 audit operator 字段
        audit_cols = [r[1] for r in c.execute('PRAGMA table_info(audit)').fetchall()]
        if 'operator' not in audit_cols:
            c.execute("ALTER TABLE audit ADD COLUMN operator TEXT DEFAULT 'system'")

        # 补全权限表
        for code, name, desc, module in PERM_DEFS:
            c.execute('INSERT OR REPLACE INTO sys_perm VALUES(?,?,?,?)', (code, name, desc, module))

        if not c.execute('SELECT 1 FROM settings').fetchone():
            s = json.dumps({'brand':'农业科技','company':'','slogan':'让农业产业链，生长出新的价值。','intro':'连接生产、流通与服务，以数字技术推动农业产业协同。','email':'','phone':'','address':'','filing':'','portalUrl':''}, ensure_ascii=False)
            c.execute('INSERT INTO settings VALUES(1,?,?,1)',(s,s))

        from seed import CONTENT
        for i, row in enumerate(CONTENT):
            if c.execute('SELECT 1 FROM content WHERE channel=? AND title=?',(row['channel'],row['title'])).fetchone():
                continue
            item = dict(row, id='seed-'+hashlib.sha1(row['title'].encode('utf-8')).hexdigest()[:16], sort=100+i, revision=1)
            meta_json = json.dumps(item.get('meta', {}), ensure_ascii=False)
            published = json.dumps(item, ensure_ascii=False)
            c.execute('INSERT INTO content(id,channel,title,summary,body,tag,sort,revision,published,updated,meta) VALUES(?,?,?,?,?,?,?,1,?,?,?)',
                      (item['id'], item['channel'], item['title'], item['summary'], item['body'], item['tag'], item['sort'], item['revision'], published, now(), meta_json))

def now():
    return time.strftime('%Y-%m-%d %H:%M:%S')

def audit(c, action, oid, operator='system'):
    c.execute('INSERT INTO audit(action,object_id,created,operator) VALUES(?,?,?,?)', (action, oid, now(), operator))

def get_user_permissions(c, user_id):
    roles = [r[0] for r in c.execute('SELECT role_id FROM sys_user_role WHERE user_id=?', (user_id,)).fetchall()]
    if 'role-super' in roles or any(r['code'] == 'super_admin' for r in c.execute('SELECT code FROM sys_role WHERE id IN ({})'.format(','.join('?'*len(roles))) if roles else 'SELECT 1 WHERE 0', roles).fetchall()):
        return [p[0] for p in PERM_DEFS], True
    if not roles:
        return [], False
    q = 'SELECT DISTINCT perm_code FROM sys_role_perm WHERE role_id IN ({})'.format(','.join('?'*len(roles)))
    perms = [r[0] for r in c.execute(q, roles).fetchall()]
    return perms, False

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT/'public'),**kwargs)

    def log_message(self,fmt,*args):
        pass

    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        super().end_headers()

    def reply(self,status,data,headers=None):
        b=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(b)))
        for k,v in (headers or {}).items():
            self.send_header(k,v)
        self.end_headers()
        self.wfile.write(b)

    def session(self):
        cookie=SimpleCookie(self.headers.get('Cookie',''))
        sid=cookie.get('company_session')
        token=sid.value if sid else ''
        session=SESSIONS.get(token)
        if session and session['expires']>time.time():
            return token,session
        if token:
            SESSIONS.pop(token,None)
        return None,None

    def check_perm(self, s, perm_code):
        if not s:
            return False
        if s.get('is_super'):
            return True
        perms = set(s.get('permissions') or [])
        return perm_code in perms

    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/public':
            with connect() as c:
                settings=json.loads(c.execute('SELECT published FROM settings WHERE id=1').fetchone()[0])
                records=[json.loads(r[0]) for r in c.execute('SELECT published FROM content WHERE published IS NOT NULL ORDER BY sort,title')]
            return self.reply(200,dict(settings=settings,records=records))

        if path=='/api/health':
            return self.reply(200,{'status':'UP'})

        if path.startswith('/api/admin'):
            _,s=self.session()
            if not s:
                return self.reply(401,{'error':'请登录内容运营后台'})

            with connect() as c:
                # 重新校验会话最新角色与权限
                if s.get('user_id'):
                    perms, is_super = get_user_permissions(c, s['user_id'])
                    s['permissions'] = perms
                    s['is_super'] = is_super

                rows=[]
                for r in c.execute('SELECT * FROM content ORDER BY sort,title'):
                    d=dict(r)
                    if d.get('meta') and isinstance(d['meta'],str):
                        try: d['meta']=json.loads(d['meta'])
                        except Exception: d['meta']={}
                    rows.append(d)
                settings=c.execute('SELECT * FROM settings WHERE id=1').fetchone()
                leads=[dict(r) for r in c.execute('SELECT * FROM leads ORDER BY created DESC LIMIT 500')]
                audit_logs=[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100')]

                # RBAC 数据装载
                orgs = [dict(r) for r in c.execute('SELECT * FROM sys_org ORDER BY sort, name')]
                roles = [dict(r) for r in c.execute('SELECT * FROM sys_role ORDER BY sort, name')]
                role_perms = {}
                for rp in c.execute('SELECT role_id, perm_code FROM sys_role_perm'):
                    role_perms.setdefault(rp['role_id'], []).append(rp['perm_code'])
                for role in roles:
                    role['permissions'] = role_perms.get(role['id'], [])

                perms_list = [dict(r) for r in c.execute('SELECT * FROM sys_perm ORDER BY module, code')]

                users = []
                for u in c.execute('''
                    SELECT u.id, u.username, u.real_name, u.org_id, u.email, u.phone, u.status, u.created, u.updated, o.name as org_name
                    FROM sys_user u
                    LEFT JOIN sys_org o ON u.org_id = o.id
                    ORDER BY u.created DESC
                '''):
                    ud = dict(u)
                    ud['roles'] = [r[0] for r in c.execute('SELECT role_id FROM sys_user_role WHERE user_id=?', (ud['id'],)).fetchall()]
                    users.append(ud)

                user_info = {
                    'username': s.get('username', 'admin'),
                    'real_name': s.get('real_name', '系统管理员'),
                    'is_super': bool(s.get('is_super')),
                    'permissions': s.get('permissions', [p[0] for p in PERM_DEFS]),
                }

                return self.reply(200, dict(
                    csrf=s['csrf'],
                    user=user_info,
                    records=rows,
                    settings=json.loads(settings['draft']),
                    settingsRevision=settings['revision'],
                    settingsPublished=json.loads(settings['published']) if settings['published'] else None,
                    leads=leads,
                    audit=audit_logs,
                    orgs=orgs,
                    roles=roles,
                    permissions=perms_list,
                    users=users
                ))

        if path.startswith('/uploads/'):
            name=path[len('/uploads/'):]
            f=UPLOADS/name
            if not UPLOAD_NAME.fullmatch(name) or not f.is_file():
                return self.reply(404,{'error':'图片不存在'})
            body=f.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type',UPLOAD_TYPES[f.suffix])
            self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','public, max-age=86400')
            self.end_headers()
            self.wfile.write(body)
            return

        if path.startswith('/api/'):
            return self.reply(404,{'error':'接口不存在'})

        if path not in ('/','/index.html','/admin.html','/app.js','/admin.js','/style.css','/robots.txt'):
            return self.reply(404,{'error':'页面不存在'})

        super().do_GET()

    def do_POST(self):
        try:
            origin=self.headers.get('Origin')
            if origin and urlparse(origin).netloc!=self.headers.get('Host'):
                return self.reply(403,{'error':'请求来源不匹配'})

            if urlparse(self.path).path=='/api/admin/upload':
                return self.upload()

            length=int(self.headers.get('Content-Length','0'))
            if length>150000 or length<=0:
                return self.reply(400,{'error':'请求大小不合法'})
            b=json.loads(self.rfile.read(length))
            path=urlparse(self.path).path
            if not isinstance(b,dict):
                raise ValueError('请求格式错误')

            ip=self.client_address[0]
            if path in ('/api/login','/api/lead'):
                key=(ip,path)
                with LOCK:
                    recent=[t for t in LIMITS.get(key,[]) if t>time.time()-300]
                    if len(recent)>=10:
                        return self.reply(429,{'error':'操作频繁，请稍后再试'})
                    LIMITS[key]=recent+[time.time()]

            # 登录接口：双轨支持（纯管理密码 OR 账号密码RBAC）
            if path=='/api/login':
                username=str(b.get('username','')).strip()
                password=str(b.get('password',''))
                env_password=os.environ.get('COMPANY_ADMIN_PASSWORD','')

                user_id = None
                real_name = '管理员'
                is_super = False
                perms = []

                if username:
                    with connect() as c:
                        u = c.execute('SELECT * FROM sys_user WHERE username=?', (username,)).fetchone()
                        if not u:
                            return self.reply(401, {'error':'账号或密码不正确'})
                        if u['status'] != 'active':
                            return self.reply(403, {'error':'该账号已被停用，请联系管理员'})
                        if not verify_pw(password, u['password_hash']):
                            return self.reply(401, {'error':'账号或密码不正确'})
                        user_id = u['id']
                        username = u['username']
                        real_name = u['real_name']
                        perms, is_super = get_user_permissions(c, user_id)
                else:
                    # 单密码兼容模式（环境变量部署密码）
                    if len(env_password)<8:
                        return self.reply(503,{'error':'请部署人员配置至少8位的后台管理密码'})
                    if not hmac.compare_digest(password, env_password):
                        return self.reply(401,{'error':'登录信息不正确'})
                    user_id = 'usr-admin'
                    username = 'admin'
                    real_name = '系统管理员'
                    is_super = True
                    perms = [p[0] for p in PERM_DEFS]

                sid=secrets.token_urlsafe(32)
                SESSIONS[sid]={
                    'expires': time.time()+7200,
                    'csrf': secrets.token_urlsafe(32),
                    'user_id': user_id,
                    'username': username,
                    'real_name': real_name,
                    'is_super': is_super,
                    'permissions': perms
                }
                secure='; Secure' if os.environ.get('COMPANY_SECURE_COOKIE')=='1' else ''
                return self.reply(200,{'ok':True, 'user':{'username':username, 'real_name':real_name, 'is_super':is_super, 'permissions':perms}},
                                  {'Set-Cookie':f'company_session={sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=7200{secure}'})

            if path=='/api/lead':
                if b.get('website'):
                    return self.reply(200,{'ok':True})
                name=field(b,'name',60)
                contact=field(b,'contact',120)
                need=field(b,'need',2000)
                if not b.get('consent'):
                    raise ValueError('请确认咨询信息使用说明')
                with connect() as c:
                    c.execute('INSERT INTO leads(id,name,contact,need,status,created) VALUES(?,?,?,?,?,?)',
                              (secrets.token_hex(8),name,contact,need,'待联系',now()))
                return self.reply(201,{'ok':True})

            sid,s=self.session()
            if not s:
                return self.reply(401,{'error':'登录已失效'})
            if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),s['csrf']):
                return self.reply(403,{'error':'请刷新页面后重试'})

            if path=='/api/logout':
                SESSIONS.pop(sid,None)
                return self.reply(200,{'ok':True},{'Set-Cookie':'company_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})

            operator_name = s.get('real_name') or s.get('username') or 'admin'

            with connect() as c:
                if path=='/api/admin/settings':
                    if not self.check_perm(s, 'settings:edit'):
                        return self.reply(403, {'error':'您没有修改站点配置的权限'})
                    r=c.execute('SELECT revision FROM settings WHERE id=1').fetchone()[0]
                    if b.get('revision')!=r:
                        return self.reply(409,{'error':'配置已更新，请刷新后编辑'})
                    data={k:field(b,k,2000,False) for k in ('brand','company','slogan','intro','email','phone','address','filing','portalUrl')}
                    if data['portalUrl'] and not re.match(r'^https://[^\s]+$',data['portalUrl']):
                        raise ValueError('产品门户地址须为完整 HTTPS 地址')
                    text=json.dumps(data,ensure_ascii=False)
                    c.execute('UPDATE settings SET draft=?,revision=revision+1 WHERE id=1',(text,))
                    if b.get('publish'):
                        c.execute('UPDATE settings SET published=? WHERE id=1',(text,))
                    audit(c,'发布站点设置' if b.get('publish') else '保存站点设置','settings', operator_name)

                elif path=='/api/admin/content':
                    if not self.check_perm(s, 'content:edit'):
                        return self.reply(403, {'error':'您没有新增或编辑内容的权限'})
                    channel=field(b,'channel',30)
                    if channel not in CHANNELS:
                        raise ValueError('栏目无效')
                    oid=str(b.get('id') or secrets.token_hex(8))
                    old=c.execute('SELECT * FROM content WHERE id=?',(oid,)).fetchone()
                    if b.get('id') and not old:
                        return self.reply(404,{'error':'内容不存在，请刷新后重试'})
                    if old and old['channel']!=channel and old['published']:
                        raise ValueError('已发布内容请先撤回再迁移栏目')
                    if old and b.get('revision')!=old['revision']:
                        return self.reply(409,{'error':'内容已更新，请刷新后编辑'})
                    meta_raw = b.get('meta') or {}
                    if not isinstance(meta_raw, dict):
                        raise ValueError('扩展属性格式错误')
                    meta_clean = validate_meta(channel, field(b,'tag',60,False), meta_raw)
                    meta_json = json.dumps(meta_clean, ensure_ascii=False)
                    item=dict(id=oid,channel=channel,title=field(b,'title',120),summary=field(b,'summary',500),body=field(b,'body',20000),tag=field(b,'tag',60,False),sort=int(b.get('sort',0)),revision=(old['revision'] if old else 0)+1,meta=meta_clean)
                    pub=old['published'] if old else None
                    c.execute('INSERT OR REPLACE INTO content VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                              (oid,channel,item['title'],item['summary'],item['body'],item['tag'],item['sort'],item['revision'],pub,now(),meta_json))
                    audit(c,'保存内容草稿',oid, operator_name)

                elif path=='/api/admin/status':
                    if not self.check_perm(s, 'content:publish'):
                        return self.reply(403, {'error':'您没有发布或撤回内容的权限'})
                    oid=field(b,'id',80)
                    r=c.execute('SELECT * FROM content WHERE id=?',(oid,)).fetchone()
                    if not r:
                        return self.reply(404,{'error':'内容不存在'})
                    if b.get('revision')!=r['revision']:
                        return self.reply(409,{'error':'内容已更新，请刷新后操作'})
                    action=b.get('action')
                    if action not in ('publish','withdraw'):
                        raise ValueError('操作无效')
                    meta_val = {}
                    if r['meta']:
                        try: meta_val = json.loads(r['meta'])
                        except Exception: meta_val = {}
                    item={k:r[k] for k in ('id','channel','title','summary','body','tag','sort','revision')}
                    item['meta'] = validate_meta(r['channel'], r['tag'], meta_val)
                    if action=='publish' and r['channel']=='about' and r['tag']=='团队介绍':
                        team=item['meta']
                        if not team.get('teamType') or not team.get('role'):
                            raise ValueError('请补全团队类型与职责')
                        if team['teamType']=='member' and team.get('publicConsent')!='1':
                            raise ValueError('请确认成员公开展示授权')
                    if action=='publish' and r['channel']=='about' and r['tag']=='团队介绍' and item['meta'].get('leadership')=='1':
                        if item['meta'].get('teamType')!='member' or not item['meta'].get('messageTitle') or not item['meta'].get('messageBody'):
                            raise ValueError('管理者寄语须关联个人成员并补全标题与正文')
                    c.execute('UPDATE content SET published=?,revision=revision+1,updated=? WHERE id=?',
                              (json.dumps(item,ensure_ascii=False) if action=='publish' else None,now(),oid))
                    audit(c,'发布内容' if action=='publish' else '撤回内容',oid, operator_name)

                elif path=='/api/admin/lead':
                    if not self.check_perm(s, 'lead:manage'):
                        return self.reply(403, {'error':'您没有处置咨询线索的权限'})
                    if b.get('status') not in ('待联系','跟进中','已完成'):
                        raise ValueError('状态无效')
                    if not c.execute('UPDATE leads SET status=?,note=? WHERE id=?',(b['status'],field(b,'note',2000,False),field(b,'id',80))).rowcount:
                        return self.reply(404,{'error':'线索不存在'})
                    audit(c,'更新咨询状态',b['id'], operator_name)

                # ========================= RBAC 组织接口 =========================
                elif path=='/api/admin/rbac/org':
                    if not self.check_perm(s, 'rbac:org:manage'):
                        return self.reply(403, {'error':'您没有管理组织架构的权限'})
                    action = b.get('action', 'save')
                    if action == 'delete':
                        oid = field(b, 'id', 80)
                        if c.execute('SELECT 1 FROM sys_org WHERE parent_id=?', (oid,)).fetchone():
                            raise ValueError('该机构下存在下级部门，请先调整下级组织')
                        if c.execute('SELECT 1 FROM sys_user WHERE org_id=?', (oid,)).fetchone():
                            raise ValueError('该部门下仍有关联人员，请先转移人员')
                        c.execute('DELETE FROM sys_org WHERE id=?', (oid,))
                        audit(c, '删除组织部门', oid, operator_name)
                    else:
                        oid = str(b.get('id') or ('org-' + secrets.token_hex(6)))
                        name = field(b, 'name', 80)
                        code = field(b, 'code', 40).upper()
                        pid = str(b.get('parent_id') or '').strip() or None
                        sort = int(b.get('sort', 0))
                        leader = field(b, 'leader', 60, False)
                        status = 'active' if b.get('status') != 'disabled' else 'disabled'
                        old = c.execute('SELECT 1 FROM sys_org WHERE code=? AND id!=?', (code, oid)).fetchone()
                        if old:
                            raise ValueError('组织编码已被占用')
                        c.execute('''
                        INSERT OR REPLACE INTO sys_org(id, name, code, parent_id, sort, status, leader, created)
                        VALUES(?,?,?,?,?,?,?,COALESCE((SELECT created FROM sys_org WHERE id=?),?))
                        ''', (oid, name, code, pid, sort, status, leader, oid, now()))
                        audit(c, '保存组织机构', oid, operator_name)

                # ========================= RBAC 角色权限接口 =========================
                elif path=='/api/admin/rbac/role':
                    if not self.check_perm(s, 'rbac:role:manage'):
                        return self.reply(403, {'error':'您没有管理角色权限的权限'})
                    action = b.get('action', 'save')
                    if action == 'delete':
                        rid = field(b, 'id', 80)
                        if rid == 'role-super':
                            raise ValueError('超级管理员角色禁止删除')
                        if c.execute('SELECT 1 FROM sys_user_role WHERE role_id=?', (rid,)).fetchone():
                            raise ValueError('该角色下仍有关联用户，请先解除绑定')
                        c.execute('DELETE FROM sys_role WHERE id=?', (rid,))
                        c.execute('DELETE FROM sys_role_perm WHERE role_id=?', (rid,))
                        audit(c, '删除管理角色', rid, operator_name)
                    else:
                        rid = str(b.get('id') or ('role-' + secrets.token_hex(6)))
                        name = field(b, 'name', 80)
                        code = field(b, 'code', 40).lower()
                        desc = field(b, 'description', 200, False)
                        sort = int(b.get('sort', 0))
                        status = 'active' if b.get('status') != 'disabled' else 'disabled'
                        perms = b.get('permissions') or []
                        if not isinstance(perms, list):
                            raise ValueError('权限配置格式不正确')
                        old = c.execute('SELECT 1 FROM sys_role WHERE code=? AND id!=?', (code, rid)).fetchone()
                        if old:
                            raise ValueError('角色编码已被占用')
                        c.execute('''
                        INSERT OR REPLACE INTO sys_role(id, name, code, description, status, sort, created)
                        VALUES(?,?,?,?,?,?,COALESCE((SELECT created FROM sys_role WHERE id=?),?))
                        ''', (rid, name, code, desc, status, sort, rid, now()))
                        c.execute('DELETE FROM sys_role_perm WHERE role_id=?', (rid,))
                        for p in set(perms):
                            if c.execute('SELECT 1 FROM sys_perm WHERE code=?', (p,)).fetchone():
                                c.execute('INSERT INTO sys_role_perm(role_id, perm_code) VALUES(?,?)', (rid, p))
                        audit(c, '配置角色权限', rid, operator_name)

                # ========================= RBAC 用户管理接口 =========================
                elif path=='/api/admin/rbac/user':
                    if not self.check_perm(s, 'rbac:user:manage'):
                        return self.reply(403, {'error':'您没有管理人员账号的权限'})
                    action = b.get('action', 'save')
                    if action == 'delete':
                        uid = field(b, 'id', 80)
                        if uid == s.get('user_id'):
                            raise ValueError('不能删除当前登录账号')
                        c.execute('DELETE FROM sys_user WHERE id=?', (uid,))
                        c.execute('DELETE FROM sys_user_role WHERE user_id=?', (uid,))
                        audit(c, '删除人员账号', uid, operator_name)
                    elif action == 'status':
                        uid = field(b, 'id', 80)
                        if uid == s.get('user_id'):
                            raise ValueError('不能停用当前登录账号')
                        new_status = 'active' if b.get('status') == 'active' else 'disabled'
                        c.execute('UPDATE sys_user SET status=?, updated=? WHERE id=?', (new_status, now(), uid))
                        audit(c, f'{("启用" if new_status=="active" else "停用")}人员账号', uid, operator_name)
                    else:
                        uid = str(b.get('id') or ('usr-' + secrets.token_hex(6)))
                        username = field(b, 'username', 40)
                        real_name = field(b, 'real_name', 60)
                        org_id = str(b.get('org_id') or '').strip() or None
                        email = field(b, 'email', 100, False)
                        phone = field(b, 'phone', 30, False)
                        status = 'active' if b.get('status') != 'disabled' else 'disabled'
                        roles = b.get('roles') or []
                        if not isinstance(roles, list):
                            raise ValueError('角色分配格式错误')

                        old = c.execute('SELECT 1 FROM sys_user WHERE username=? AND id!=?', (username, uid)).fetchone()
                        if old:
                            raise ValueError('用户名已被占用')

                        pw = str(b.get('password') or '').strip()
                        if not b.get('id') and not pw:
                            pw = 'Admin@123'
                        if pw and len(pw) < 8:
                            raise ValueError('密码长度至少 8 位')

                        if b.get('id'):
                            if pw:
                                p_hash = hash_pw(pw)
                                c.execute('''
                                UPDATE sys_user SET username=?, real_name=?, password_hash=?, org_id=?, email=?, phone=?, status=?, updated=?
                                WHERE id=?
                                ''', (username, real_name, p_hash, org_id, email, phone, status, now(), uid))
                            else:
                                c.execute('''
                                UPDATE sys_user SET username=?, real_name=?, org_id=?, email=?, phone=?, status=?, updated=?
                                WHERE id=?
                                ''', (username, real_name, org_id, email, phone, status, now(), uid))
                        else:
                            p_hash = hash_pw(pw)
                            c.execute('''
                            INSERT INTO sys_user(id, username, real_name, password_hash, org_id, email, phone, status, created, updated)
                            VALUES(?,?,?,?,?,?,?,?,?,?)
                            ''', (uid, username, real_name, p_hash, org_id, email, phone, status, now(), now()))

                        c.execute('DELETE FROM sys_user_role WHERE user_id=?', (uid,))
                        for r_id in set(roles):
                            if c.execute('SELECT 1 FROM sys_role WHERE id=?', (r_id,)).fetchone():
                                c.execute('INSERT INTO sys_user_role(user_id, role_id) VALUES(?,?)', (uid, r_id))
                        audit(c, '保存人员账号与角色', uid, operator_name)
                else:
                    return self.reply(404,{'error':'接口不存在'})

            return self.reply(200,{'ok':True})
        except (ValueError,TypeError,KeyError) as e:
            self.reply(400,{'error':str(e) if isinstance(e,ValueError) and len(str(e))>8 else '请检查必填内容、长度和数据格式'})
        except Exception as e:
            self.reply(500,{'error':f'服务处理失败：{str(e)}'})

def _upload(self):
    _,s=self.session()
    if not s:
        return self.reply(401,{'error':'登录已失效'})
    if not self.check_perm(s, 'content:upload'):
        return self.reply(403,{'error':'您没有上传素材的权限'})
    if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),s['csrf']):
        return self.reply(403,{'error':'请刷新页面后重试'})
    try:
        length=int(self.headers.get('Content-Length','0'))
    except ValueError:
        length=0
    if length<=0:
        return self.reply(400,{'error':'未收到图片内容'})
    if length>UPLOAD_MAX:
        return self.reply(413,{'error':'图片不能超过 2MB'})
    data=self.rfile.read(length)
    if data[:3]==b'\xff\xd8\xff':
        ext='.jpg'
    elif data[:8]==b'\x89PNG\r\n\x1a\n':
        ext='.png'
    elif len(data)>12 and data[:4]==b'RIFF' and data[8:12]==b'WEBP':
        ext='.webp'
    else:
        return self.reply(400,{'error':'仅支持 JPG、PNG、WEBP 格式的图片'})
    name=secrets.token_hex(16)+ext
    UPLOADS.mkdir(parents=True,exist_ok=True)
    (UPLOADS/name).write_bytes(data)
    with connect() as c:
        audit(c,'上传肖像图片',name, s.get('real_name') or 'admin')
    return self.reply(200,{'ok':True,'url':'/uploads/'+name})

Handler.upload=_upload

def validate_meta(channel, tag, raw):
    from datetime import date
    if not isinstance(raw, dict):
        raise ValueError('扩展属性格式错误')
    if channel == 'about' and tag == '发展历程':
        allowed = ('year', 'date', 'milestone')
    elif channel == 'about' and tag == '资质荣誉':
        allowed = ('year', 'issuer', 'certNo', 'validUntil', 'verifyUrl')
    elif channel == 'about' and tag == '团队介绍':
        allowed = ('teamType', 'role', 'department', 'expertise', 'serviceScope', 'publicConsent', 'teamCategory', 'englishName', 'portraitUrl', 'leadership', 'messageTitle', 'messageDate', 'messageBody')
    elif channel == 'products':
        allowed = ('badge', 'targetScale', 'coreFeatures', 'archLayer')
    elif channel == 'solutions':
        allowed = ('targetIndustry', 'painPoints', 'deliveryCycle', 'relatedProducts')
    elif channel == 'cases':
        allowed = ('clientType', 'caseScene', 'outcomes', 'relatedSolution')
    else:
        allowed = ()
    meta = {}
    for key in allowed:
        value = raw.get(key, '')
        if not isinstance(value, str):
            raise ValueError('扩展属性须为文本')
        value = value.strip()
        max_len = 4000 if key=='messageBody' else 2000 if key in ('coreFeatures','painPoints','outcomes','relatedProducts') else 500
        if len(value)>max_len:
            raise ValueError(f'{key} 属性内容过长，请适当精简')
        if value:
            meta[key]=value
    if channel=='about' and tag=='团队介绍':
        if meta.get('teamCategory') not in (None,'board','executive','expert','professional'):
            raise ValueError('管理团队分类无效')
        if meta.get('leadership') not in (None,'1'):
            raise ValueError('管理者寄语标识无效')
        for key, maximum in {'englishName':100,'messageTitle':120}.items():
            if len(meta.get(key,''))>maximum:
                raise ValueError('管理团队字段过长')
        if meta.get('messageDate'):
            date.fromisoformat(meta['messageDate'])
        if meta.get('portraitUrl'):
            if not re.fullmatch(r'/uploads/[a-f0-9]{32}\.(jpg|png|webp)',meta['portraitUrl']):
                raise ValueError('肖像图片须通过后台上传')
        if meta.get('teamType') not in (None,'member','group'):
            raise ValueError('团队类型无效')
        if meta.get('publicConsent') not in (None,'1'):
            raise ValueError('展示授权标识无效')
        for key, maximum in {'role':100,'department':80,'expertise':300,'serviceScope':500}.items():
            if len(meta.get(key,''))>maximum:
                raise ValueError('团队字段过长')
    if meta.get('year') and not re.fullmatch(r'(19|20|21)\d{2}',meta['year']):
        raise ValueError('年份格式错误')
    def check_date(value):
        if not re.fullmatch(r'\d{4}-\d{2}(-\d{2})?', value):
            raise ValueError('日期格式错误')
        return date.fromisoformat(value+'-01' if len(value)==7 else value)
    if meta.get('date'):
        check_date(meta['date'])
        if meta.get('year') and not meta['date'].startswith(meta['year']+'-'):
            raise ValueError('年份与日期不一致')
    if meta.get('milestone') not in (None,'1'):
        raise ValueError('里程碑标识错误')
    if meta.get('validUntil') and meta['validUntil']!='长期':
        check_date(meta['validUntil'])
    if meta.get('verifyUrl'):
        parsed=urlparse(meta['verifyUrl'])
        if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or any(c.isspace() for c in meta['verifyUrl']):
            raise ValueError('核验地址须为HTTPS')
    return meta

def field(b,k,maximum,required=True):
    v=str(b.get(k,'')).strip()
    if len(v)>maximum or (required and not v):
        raise ValueError(k)
    return v

if __name__=='__main__':
    initialize()
    ThreadingHTTPServer((os.environ.get('COMPANY_HOST','127.0.0.1'),int(os.environ.get('COMPANY_PORT','8188'))),Handler).serve_forever()
