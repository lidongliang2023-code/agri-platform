let data;const $=s=>document.querySelector(s);
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const names={products:'产品频道',solutions:'解决方案',cases:'标杆案例',about:'关于我们',support:'服务支持',partners:'生态伙伴'};
let search='',tag='全部';
const rows=k=>data.records.filter(r=>r.channel===k);
const icons=['田','感','链','数','溯','碳'];

function parseMeta(r){
  if(r && typeof r.meta === 'object' && r.meta !== null) return r.meta;
  if(r && typeof r.meta === 'string'){
    try{ return JSON.parse(r.meta)||{} }catch{ return {} }
  }
  return {};
}

function qualificationStatus(m){
  if(m.validUntil==='长期') return '长期有效';
  if(!m.validUntil) return '有效期未标注';
  const value=m.validUntil;
  const end=value.length===7?new Date(Number(value.slice(0,4)),Number(value.slice(5,7)),0,23,59,59):new Date(value+'T23:59:59');
  if(Number.isNaN(end.getTime())) return '有效期待核实';
  const days=(end-new Date())/86400000;
  return days<0?'已到期':days<=90?'90天内到期':'有效期内';
}
function isExpired(value){ if(!value) return false; const t=Date.parse(value); return Number.isFinite(t) && t < Date.now(); }
function safeVerifyUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password?u.href:''}catch{return ''}}

const heroVisual = `<div class="cyber-hero-stage" aria-hidden="true">
  <!-- 四角工业科技卡榫 -->
  <span class="stage-bracket tl"></span>
  <span class="stage-bracket tr"></span>
  <span class="stage-bracket bl"></span>
  <span class="stage-bracket br"></span>

  <!-- 顶部遥测与卫星轨道指标 -->
  <div class="cyber-telemetry-strip">
    <div class="tele-left"><span class="tele-beacon"></span><small>ORBIT: HJ-2B / GF-6</small></div>
    <div class="tele-coords">24°30'42"N · 117°39'18"E</div>
    <div class="tele-status">SYNC: 100%</div>
  </div>

  <div class="cyber-radar-ring r1"></div>
  <div class="cyber-radar-ring r2"></div>
  <div class="cyber-radar-ring r3"></div>
  <div class="cyber-radar-sweep"></div>
  <div class="cyber-grid-plane"></div>
  <div class="cyber-glow-core"></div>
  
  <!-- 核心数字孪生节点 -->
  <div class="cyber-node-hub">
    <div class="hub-orbit-dot o-dot1"></div>
    <div class="hub-orbit-dot o-dot2"></div>
    <div class="hub-icon">禾</div>
    <div class="hub-label">农业产业大脑中枢<small>AGRI-BRAIN HUB · ACTIVE</small></div>
    <span class="hub-pulse"></span>
  </div>

  <!-- 浮动多维遥感感知卡 -->
  <div class="cyber-float-card fc-sensor">
    <div class="cfc-head">
      <span class="cfc-dot green"></span>
      <b>天空地一体化遥感</b>
      <span class="cfc-tag">实时接入</span>
    </div>
    <div class="cfc-body">
      <div class="cfc-metric"><small>植被指数 NDVI</small><strong>0.84 <span>优良</span></strong></div>
      <div class="cfc-metric"><small>土壤水肥墒情</small><strong>22.5% <span>适宜</span></strong></div>
    </div>
    <div class="cfc-bar"><span style="width: 82%"></span></div>
    <div class="cfc-wave-row">
      <span class="spark-bar h1"></span><span class="spark-bar h3"></span><span class="spark-bar h2"></span>
      <span class="spark-bar h4"></span><span class="spark-bar h3"></span><span class="spark-bar h5"></span>
      <span class="spark-bar h2"></span><span class="spark-bar h4"></span><span class="spark-bar h1"></span>
    </div>
  </div>

  <!-- 浮动供应链履约卡 -->
  <div class="cyber-float-card fc-chain">
    <div class="cfc-head">
      <span class="cfc-dot blue"></span>
      <b>产业协同与订单履约</b>
      <span class="cfc-tag">撮合中</span>
    </div>
    <div class="cfc-body">
      <div class="cfc-metric"><small>在途批次冷链温控</small><strong>-2℃ ~ 4℃ <span>正常</span></strong></div>
      <div class="cfc-metric"><small>全网供需撮合效率</small><strong>&lt; 15s <span>极速响应</span></strong></div>
    </div>
    <div class="cfc-pulse-line"></div>
  </div>

  <!-- 浮动可信质溯源与绿色双碳卡 -->
  <div class="cyber-float-card fc-trace">
    <div class="cfc-head">
      <span class="cfc-dot gold"></span>
      <b>一物一码 · 可信存证</b>
      <span class="cfc-tag">区块链锚定</span>
    </div>
    <div class="cfc-trace-row">
      <span>✓ 农事作业闭环</span>
      <span>✓ 投入品合规</span>
      <span>✓ VR实景核验</span>
      <span>✓ 碳足迹核算</span>
    </div>
  </div>

  <!-- 动态科技角标与流向指示 -->
  <div class="cyber-stage-badge">
    <span>FULL-STACK AGRI-TECH ECOSYSTEM</span>
    <strong>涵盖生产 · 物联 · 交易 · 数据 · 溯源 · 双碳</strong>
  </div>
</div>`;

function splitList(str){
  if(!str) return [];
  return str.split(/[,，、\n]+/).map(s=>s.trim()).filter(Boolean);
}

function productCard(r,i){
  const m=parseMeta(r);
  const badge=m.badge||r.tag||'核心产品';
  const scale=m.targetScale||'龙头企业 / 产业基地 / 合作社';
  const features=splitList(m.coreFeatures);
  const layer=m.archLayer||'业务协同层';
  return `<article class="product-pro-card">
    <div class="card-glass-header">
      <div class="badge-group">
        <span class="product-badge">${escape(badge)}</span>
        <span class="product-layer-tag">${escape(layer)}</span>
      </div>
      <b class="product-icon" aria-hidden="true">${icons[i%icons.length]}</b>
    </div>
    <div class="product-pro-body">
      <h3>${escape(r.title)}</h3>
      <p class="product-summary">${escape(r.summary)}</p>
      <div class="product-scale-box">
        <small>适配规模</small>
        <span>${escape(scale)}</span>
      </div>
      ${features.length?`<div class="product-feature-tags">${features.slice(0,4).map(f=>`<span>✓ ${escape(f)}</span>`).join('')}</div>`:''}
    </div>
    <div class="product-card-footer">
      <a class="btn-card-primary" href="#/detail/${encodeURIComponent(r.id)}">查看产品能力 ↗</a>
      <a class="btn-card-sub" href="#/about?section=contact">预约体验</a>
    </div>
  </article>`;
}

function solutionCard(r,i){
  const m=parseMeta(r);
  const industry=m.targetIndustry||r.tag||'现代农业产业';
  const cycle=m.deliveryCycle||'按项目范围确认';
  const pains=splitList(m.painPoints);
  const prods=splitList(m.relatedProducts);
  return `<article class="solution-pro-card">
    <div class="sol-card-index">
      <span class="sol-num">0${i+1}</span>
      <span class="sol-ind-pill">${escape(industry)}</span>
    </div>
    <div class="sol-card-content">
      <h3>${escape(r.title)}</h3>
      <p class="sol-summary">${escape(r.summary)}</p>
      <div class="sol-breakdown">
        ${pains.length?`<div class="sol-block"><small>行业痛点</small><p>${pains.slice(0,2).map(p=>`• ${escape(p)}`).join('<br>')}</p></div>`:''}
        ${prods.length?`<div class="sol-block"><small>组合产品</small><div class="sol-chips">${prods.slice(0,3).map(p=>`<span>${escape(p)}</span>`).join('')}</div></div>`:''}
      </div>
    </div>
    <div class="sol-card-foot">
      <div class="sol-cycle"><small>建设周期</small><b>${escape(cycle)}</b></div>
      <a class="sol-link" href="#/detail/${encodeURIComponent(r.id)}">方案蓝图与路径 ↗</a>
    </div>
  </article>`;
}

function caseCard(r){
  const m=parseMeta(r);
  const clientType=m.clientType||'农业龙头主体';
  const scene=m.caseScene||r.tag||'产业协同示范';
  const outcomes=splitList(m.outcomes);
  return `<article class="case-pro-card">
    <div class="case-card-header">
      <span class="case-client-type">${escape(clientType)}</span>
      <span class="case-scene-pill">${escape(scene)}</span>
    </div>
    <h3>${escape(r.title)}</h3>
    <p class="case-summary">${escape(r.summary)}</p>
    ${outcomes.length?`<div class="case-outcome-box">
      <small>核心实效与核验记录</small>
      <ul>${outcomes.slice(0,3).map(o=>`<li>★ ${escape(o)}</li>`).join('')}</ul>
    </div>`:''}
    <div class="case-card-footer">
      <a class="case-btn-detail" href="#/detail/${encodeURIComponent(r.id)}">案例建设复盘 ↗</a>
      ${m.relatedSolution?`<a class="case-link-sol" href="#/solutions">了解对应方案 →</a>`:''}
    </div>
  </article>`;
}

function cards(records){
  return records.map((r,i)=>{
    if(r.channel==='products') return productCard(r,i);
    if(r.channel==='solutions') return solutionCard(r,i);
    if(r.channel==='cases') return caseCard(r);
    return `<a class="content-card" href="#/detail/${encodeURIComponent(r.id)}"><span class="card-top"><span>${escape(r.tag||names[r.channel])}</span><b>${icons[i%icons.length]}</b></span><h3>${escape(r.title)}</h3><p>${escape(r.summary)}</p><span class="card-link">探索${r.channel==='products'?'产品能力':'更多内容'}<b>↗</b></span></a>`;
  }).join('');
}

function heading(en,title,desc){
  return `<div class="section-title"><div><span class="eyebrow">${en}</span><h2>${title}</h2></div><p>${desc}</p></div>`;
}

function footer(){
  const s=data.settings;
  $('#brand').textContent=s.brand||'农业科技';
  $('#footer').innerHTML=`<div class="footer-main">
    <div>
      <strong>${escape(s.company||s.brand||'农业科技')}</strong>
      <p>${escape(s.intro||'扎根农业现场，连接产业的每一步。')}</p>
      <span class="footer-motto">扎根产业 · 向新而行</span>
    </div>
    <div>
      <h4>探索官网</h4>
      <a href="#/about?section=overview">公司介绍</a>
      <a href="#/about?section=team">管理团队</a>
      <a href="#/about?section=history">发展历程</a>
      <a href="#/about?section=honors">资质荣誉</a>
      <a href="#/products">产品生态</a>
      <a href="#/solutions">解决方案</a>
      <a href="#/cases">标杆案例</a>
      <a href="#/support">服务支持</a>
      <a href="#/partners">生态伙伴</a>
    </div>
    <div>
      <h4>联系与合作</h4>
      ${s.phone?`<p>电话：${escape(s.phone)}</p>`:''}
      ${s.email?`<p>邮箱：${escape(s.email)}</p>`:''}
      ${s.address?`<p>地址：${escape(s.address)}</p>`:''}
      <a href="#/about?section=contact">提交合作需求 ↗</a>
      ${s.portalUrl?`<a href="${escape(s.portalUrl)}" target="_blank" rel="noopener noreferrer">进入业务门户 ↗</a>`:''}
    </div>
  </div>
  <div class="footer-bottom">
    <span>© ${new Date().getFullYear()} ${escape(s.company||s.brand)} · 让农业与数字技术同行</span>
    <span>${escape(s.filing||'ICP 备 20260001 号')}</span>
  </div>`;
}

function cta(){
  return '<section class="cta"><div><span class="eyebrow">LET’S GROW TOGETHER</span><h2>下一段产业生长，<br>从一次对话开始。</h2><p>从业务梳理、场景匹配到落地运营，与您共同规划农业数字化蓝图。</p></div><a class="btn light" href="#/about?section=contact">开启合作交流 ↗</a></section>';
}

function caseEmpty(){
  return '<div class="empty wide case-empty"><span>REAL PROJECTS · REAL VALUE</span><h3>让真实实践，成为最好的表达。</h3><p>真实案例正在整理，完成客户授权与资料核验后发布。<br>您可以先了解我们的方案与建设路径。</p><a href="#/solutions">探索行业解决方案 ↗</a></div>';
}

function home(){
  const s = data.settings;
  const brandName = s.brand || '丰链云';
  const prods = rows('products');
  const sols = rows('solutions');
  const caseList = rows('cases');

  return `<section class="super-hero">
    <div class="hero-aurora-bg"></div>
    <div class="hero-grid-mesh"></div>
    <div class="super-hero-content">
      <div class="super-hero-copy">
        <div class="hero-pill-badge">
          <span class="badge-beacon"></span>
          <span class="badge-text">中国现代农业产业互联网 · 数字化赋能平台</span>
          <span class="badge-arrow">↗</span>
        </div>
        <h1 class="super-hero-title">
          让每一寸沃土，<br>
          <span class="text-gradient-gold">澎湃数字力量。</span>
        </h1>
        <p class="super-hero-lead">
          ${escape(s.intro || '深耕农业产业链，以数字技术打通生产、流通、服务与监管，构建从田间地头到餐桌的全链路数字协同生态。')}
        </p>
        <div class="super-hero-actions">
          <a class="btn-hero-glow" href="#/solutions">
            <span>探索行业解决方案</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </a>
          <a class="btn-hero-glass" href="#/products">
            <span>浏览产品矩阵</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
          </a>
          <a class="hero-consult-link" href="#/about?section=contact">
            <span>预约专家咨询与演示 ↗</span>
          </a>
        </div>
        
        <!-- 核心产业宏观数据背书 -->
        <div class="super-hero-metrics">
          <div class="metric-item">
            <span class="metric-num">100<small>+</small></span>
            <span class="metric-label">现代农业示范基地服务</span>
          </div>
          <div class="metric-item">
            <span class="metric-num">6<small>大</small></span>
            <span class="metric-label">全栈数字化协同引擎</span>
          </div>
          <div class="metric-item">
            <span class="metric-num">360<small>°</small></span>
            <span class="metric-label">天空地一体化实景可信</span>
          </div>
          <div class="metric-item">
            <span class="metric-num">0<small>碳</small></span>
            <span class="metric-label">绿色双碳与合规监管</span>
          </div>
        </div>
      </div>
      
      <div class="super-hero-stage-wrap">
        ${heroVisual}
      </div>
    </div>

    <!-- 底部微流动引导条 -->
    <div class="super-hero-bottom-bar">
      <div class="shb-left">
        <span class="shb-dot"></span>
        <span class="shb-text">以产业为根基 · 以数据为血脉 · 赋能农业现代化高质量发展</span>
      </div>
      <a class="shb-scroll" href="#/?section=flywheel">
        <span>向下探索全景能力</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M19 12l-7 7-7-7"/></svg>
      </a>
    </div>
  </section>

  <!-- 全产业链数字飞轮 / 能力矩阵导航条 -->
  <div class="flywheel-section" id="flywheel">
    <div class="flywheel-header">
      <span class="eyebrow-accent">END-TO-END VALUE CHAIN</span>
      <h2>贯穿农业全产业链 · 释放六维数字生产力</h2>
      <p>打破生产、物联、供应链、资讯、溯源与绿色双碳之间的数据孤岛，实现一体化闭环赋能</p>
    </div>
    <div class="flywheel-grid">
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>01</b><span>田</span></div>
        <div class="fc-text">
          <h3>智能生产管理</h3>
          <p>地块排程 · 农事闭环 · 采收记工</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>02</b><span>感</span></div>
        <div class="fc-text">
          <h3>农业物联网感知</h3>
          <p>环境监测 · 边缘控制 · 预警联动</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>03</b><span>链</span></div>
        <div class="fc-text">
          <h3>产业交易与供应链</h3>
          <p>货源撮合 · 冷链履约 · 金融赋能</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>04</b><span>数</span></div>
        <div class="fc-text">
          <h3>产业大数据与资讯</h3>
          <p>批发采集 · 价格指数 · 产销研判</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>05</b><span>溯</span></div>
        <div class="fc-text">
          <h3>质量溯源与VR实景</h3>
          <p>一物一码 · 全景看货 · 远程验厂</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
      <a class="flywheel-card" href="#/products">
        <div class="fc-icon-box"><b>06</b><span>碳</span></div>
        <div class="fc-text">
          <h3>绿色双碳与产业监管</h3>
          <p>碳排放核算 · 绿色认证 · 监管合规</p>
        </div>
        <span class="fc-arrow">↗</span>
      </a>
    </div>
  </div>

  <!-- 旗舰级产品矩阵（PRODUCT ECOSYSTEM） -->
  <section class="section home-products-section">
    <div class="section-title text-center">
      <span class="eyebrow-accent">ENTERPRISE-GRADE PRODUCT ECOSYSTEM</span>
      <h2>以国家级技术底座，构建现代化农业产品矩阵</h2>
      <p class="section-desc">沉淀多年农业产业数字化经验，模块解耦、灵活组合，既支持单点极速上线，亦可承载区域级统筹重构。</p>
    </div>
    
    <!-- 旗舰级双核平台大画幅展示 -->
    <div class="flagship-duo-grid">
      <div class="flagship-card primary">
        <div class="flagship-badge">旗舰核心 · 生产与感知</div>
        <div class="flagship-content">
          <div class="flagship-icon">田</div>
          <span class="flagship-tag">智慧农业生产协同平台</span>
          <h3>数字化农场大脑，实现生产全程精细化</h3>
          <p>以基地与地块为核心单元，将水肥农事计划、农机作业追踪、投入品合规核验与采收批次管理彻底无缝贯通，让农事作业可追溯、可量化、可复制。</p>
          <div class="flagship-features">
            <span>✓ 智能地块画定与农事排程</span>
            <span>✓ 投入品合规扫描与禁限用拦截</span>
            <span>✓ 农机具协同与采收批次流转</span>
            <span>✓ 无缝联动一物一码可信溯源</span>
          </div>
          <div class="flagship-footer">
            <a class="btn-card-primary" href="#/detail/19d3a5ab169db744">了解平台详情 ↗</a>
            <span class="flagship-scale">适配：农业产业化龙头企业 / 规模化种植示范基地</span>
          </div>
        </div>
      </div>

      <div class="flagship-card secondary">
        <div class="flagship-badge">旗舰核心 · 供应链协同</div>
        <div class="flagship-content">
          <div class="flagship-icon">链</div>
          <span class="flagship-tag">产业交易与智慧供应链平台</span>
          <h3>产销撮合与履约协同，构建高效农产大市场</h3>
          <p>打破传统产地与批发市场间的信息壁垒，连接真实农特货源与大宗采购需求，打通订单协同、多级冷链物流追踪与供应链金融可信通道。</p>
          <div class="flagship-features">
            <span>✓ 农特供需撮合与智能行情匹配</span>
            <span>✓ 在途温控与冷链物流全时监控</span>
            <span>✓ 履约单据实时核验与结算通道</span>
            <span>✓ 银行与金融机构可信数据底盘</span>
          </div>
          <div class="flagship-footer">
            <a class="btn-card-primary" href="#/detail/48070383703479b0">了解平台详情 ↗</a>
            <span class="flagship-scale">适配：农产品批发商 / 渠道商 / 产销合作社</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 其余专业平台矩阵 -->
    <div class="sub-products-grid">
      ${cards(prods.filter(r => !['智慧农业生产平台','产业交易与供应链平台'].includes(r.title)).slice(0, 4))}
    </div>
    
    <div class="section-center-action">
      <a class="btn-grand-outline" href="#/products">
        <span>查看完整 6 大数字化产品能力体系</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </a>
    </div>
  </section>

  <!-- 创新技术高光：农业产业大脑与实景可视化数字座舱 -->
  <section class="section cyber-cockpit-section">
    <div class="cockpit-container">
      <div class="cockpit-header">
        <div class="cockpit-lead">
          <span class="eyebrow-accent">AGRI-BRAIN DIGITAL COCKPIT</span>
          <h2>产业大脑驾驶舱 · 一屏统揽产业态势</h2>
          <p>将复杂的农业多源异构数据（天空地遥感、气象墒情、现货行情、物流轨迹、碳排数据）汇聚提炼为实时决策资产，让农业运营真正具备前瞻研判能力。</p>
        </div>
        <a class="btn-hero-glow" href="#/about?section=contact">
          <span>申请接入产业大脑演示</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
      </div>
      
      <!-- 驾驶舱仿真大屏展示面板 -->
      <div class="cockpit-board-mock">
        <div class="cbm-top-bar">
          <div class="cbm-brand">
            <span class="cbm-led"></span>
            <b>现代农业全景态势感知中枢</b>
            <small>AGRI-INTELLIGENCE CENTER · ONLINE</small>
          </div>
          <div class="cbm-stats-strip">
            <span>基地在测: <strong>1,280 亩</strong></span>
            <span>传感器节点: <strong>468 台套</strong></span>
            <span>当日行情波动: <strong class="green">+1.8% 稳定</strong></span>
            <span>区块链存证: <strong>100% 校验</strong></span>
          </div>
        </div>
        
        <div class="cbm-grid">
          <!-- 模块1：天空地多光谱感知沙盘 -->
          <div class="cbm-widget w-map">
            <div class="cbm-w-title">
              <span>🛰️ 天空地多光谱遥感与基地沙盘</span>
              <small>遥感重访周期: 3天</small>
            </div>
            <div class="cbm-map-visual">
              <div class="cbm-map-grid"></div>
              <div class="cbm-scan-line"></div>
              <div class="cbm-pin p1"><span>示范大棚 A-01</span></div>
              <div class="cbm-pin p2"><span>智能水肥区 B-04</span></div>
              <div class="cbm-pin p3"><span>冷链集配港 C-02</span></div>
              <div class="cbm-map-hud">
                <div>光照强度: 48,000 Lux</div>
                <div>环境温度: 24.6 ℃</div>
                <div>空气湿度: 68 %RH</div>
                <div>土壤EC值: 1.2 mS/cm</div>
              </div>
            </div>
          </div>

          <!-- 模块2：行情价格指数与预测雷达 -->
          <div class="cbm-widget w-market">
            <div class="cbm-w-title">
              <span>📈 大宗农产品价格指数基准</span>
              <small>覆盖全国80+核心批发市场</small>
            </div>
            <div class="cbm-chart-mock">
              <div class="chart-bars">
                <div class="c-bar" style="height: 60%"><span>周一</span></div>
                <div class="c-bar" style="height: 75%"><span>周二</span></div>
                <div class="c-bar" style="height: 65%"><span>周三</span></div>
                <div class="c-bar" style="height: 85%"><span>周四</span></div>
                <div class="c-bar active" style="height: 92%"><span>今日 4.85元/斤</span></div>
              </div>
              <div class="cbm-market-tags">
                <span>价格异动预警: 正常</span>
                <span>采集样本量: 12,400条/日</span>
              </div>
            </div>
          </div>

          <!-- 模块3：VR 云工厂全景实景视讯探针 -->
          <div class="cbm-widget w-vr">
            <div class="cbm-w-title">
              <span>🥽 VR 云工厂实景看货与远程验厂</span>
              <small>360° 超高清实景</small>
            </div>
            <div class="cbm-vr-preview">
              <div class="vr-badge">LIVE · 基地实景连线</div>
              <div class="vr-center-tag">漳州现代柑橘立体种植示范园</div>
              <div class="vr-actions-hint">支持全视角云端巡检 · 客户免跑腿远程验厂</div>
            </div>
          </div>

          <!-- 模块4：绿色低碳与碳足迹核算 -->
          <div class="cbm-widget w-carbon">
            <div class="cbm-w-title">
              <span>🌱 绿色供应链与双碳减排看板</span>
              <small>范围一/二/三全口径</small>
            </div>
            <div class="cbm-carbon-data">
              <div class="carbon-ring-box">
                <div class="carbon-ring">
                  <span>-18.4%</span>
                  <small>亩均减碳</small>
                </div>
              </div>
              <div class="carbon-desc">
                <div>节水节肥增效: <strong>+24.6%</strong></div>
                <div>绿证赋码合规率: <strong>100%</strong></div>
                <div>绿色出口认证: <strong>已完成合规备案</strong></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 场景化解决方案蓝图（INDUSTRY SOLUTIONS） -->
  <section class="section solutions-section">
    <div class="section-title text-center">
      <span class="eyebrow-accent">SCENARIO-DRIVEN SOLUTIONS</span>
      <h2>针对农业不同发展阶段，定制专业化破局路径</h2>
      <p class="section-desc">无论是单体示范基地的高标准建设，还是区域产业集群的生态重塑，均提供从咨询蓝图到实施运营的全程护航。</p>
    </div>
    
    <div class="solutions-showcase-grid">
      ${sols.slice(0, 3).map((r, i) => solutionCard(r, i)).join('')}
    </div>

    <div class="section-center-action">
      <a class="btn-grand-outline" href="#/solutions">
        <span>了解详细解决方案与实施路径</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </a>
    </div>
  </section>

  <!-- 严谨求实的落地案例与客户实践（SELECTED STORIES） -->
  <section class="section cases-section soft">
    <div class="section-title text-center">
      <span class="eyebrow-accent">CLIENT SUCCESS STORIES</span>
      <h2>扎根泥土，见证数字科技带来的真实改变</h2>
      <p class="section-desc">坚持以实效为度量衡，用真实的数据和口碑，回应当下农业产业转型中的每一个痛点。</p>
    </div>

    <div class="cases-showcase-wrap">
      ${caseList.length ? `<div class="cases-grid">${cards(caseList.slice(0, 3))}</div>` : caseEmpty()}
    </div>
  </section>

  <!-- 现代化农业服务理念（OUR PERSPECTIVE） -->
  <section class="grand-perspective-section">
    <div class="perspective-container">
      <div class="perspective-left">
        <span class="eyebrow-accent light">WHY US · 懂农业的数字化伙伴</span>
        <h2>不是简单的软件堆砌，<br>而是真正伴随产业生长的长期同行者。</h2>
        <p>我们不仅拥有自主研发的现代化工业级软件与物联网边缘算法底座，更拥有一支长期扎根田间地头、深谙农耕规律、农特流通与合规标准的复合型行业专家团队。</p>
        <div class="perspective-pillars">
          <div class="pillar-box">
            <b>01</b>
            <h4>深入产业一线</h4>
            <p>从土壤、水肥、农事规程到批发流通链路，尊重农业自然规律与业务逻辑。</p>
          </div>
          <div class="pillar-box">
            <b>02</b>
            <h4>自主可信底座</h4>
            <p>分布式物联接入、区块链存证锚定、国密级数据安全，保障产业数字主权。</p>
          </div>
          <div class="pillar-box">
            <b>03</b>
            <h4>端到端敏捷交付</h4>
            <p>从方案蓝图到驻场实施、持续运营培训，确保系统“用得起、用得上、用得好”。</p>
          </div>
        </div>
      </div>
      <div class="perspective-right">
        <div class="perspective-quote-card">
          <div class="quote-mark">“</div>
          <h3>数字农业的终极意义，是让付出劳动的农人获得体面回报，让优质农产品卖出品牌价值，让每一份绿水青山变成高质量的金山银山。</h3>
          <div class="quote-author">
            <strong>${brandName} 产业数字化研究院</strong>
            <small>FOCUSING ON AGRICULTURAL MODERNIZATION</small>
          </div>
          <div class="quote-action">
            <a class="btn-hero-glow" href="#/about">认识我们与专业团队 ↗</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 宏大大气的行动号召（HEROIC GRAND CTA） -->
  ${cta()}`;
}

const managementCategories={'board':'董事会','executive':'经营管理层','expert':'专家顾问','professional':'专业团队'};

function managementCard(r){
  const m=parseMeta(r);
  return `<a class="management-card" href="#/detail/${encodeURIComponent(r.id)}">
    <div class="management-portrait">${m.portraitUrl?`<img src="${escape(m.portraitUrl)}" alt="${escape(r.title)}" loading="lazy">`:`<span aria-hidden="true">${escape(r.title.slice(0,1))}</span>`}</div>
    <div class="management-card-copy">
      <small>${escape(managementCategories[m.teamCategory]||'团队成员')}</small>
      <h3>${escape(r.title)}</h3>
      ${m.englishName?`<small class="management-en">${escape(m.englishName)}</small>`:''}
      <p class="team-role">${escape(m.role||'')}</p>
      <p>${escape(r.summary)}</p>
      <span class="management-more">查看履历与职责 ↗</span>
    </div>
  </a>`;
}

function companyAbout(){
  const s=data.settings, all=rows('about').filter((r,i,a)=>a.findIndex(v=>v.title===r.title&&v.tag===r.tag)===i), group=t=>all.filter(r=>r.tag===t), special=['发展历程','资质荣誉','团队介绍','服务理念','公司介绍','新闻与活动'];
  const intro=all.filter(r=>!special.includes(r.tag)||r.tag==='公司介绍');
  const blocks=(list)=>list.map(r=>`<article class="about-copy"><h3>${escape(r.title)}</h3><p>${escape(r.summary)}</p>${r.body.split('\n').filter(Boolean).map(v=>`<p>${escape(v)}</p>`).join('')}</article>`).join('');
  const layers=[
    ['04','产业协同','交易供需、商家运营、物流服务与供应链服务','products'],
    ['03','可信与绿色','质量溯源、VR 云工厂、碳核算与绿色认证','products'],
    ['02','生产与感知','基地地块、农事计划、采收管理与物联网监测','products'],
    ['01','数据与治理','行情资讯、数据质量、主体认证与政府监管','products']
  ];

  const teamList=group('团队介绍');
  const leaders=teamList.filter(r=>parseMeta(r).leadership==='1'&&parseMeta(r).messageBody);
  const histories=group('发展历程').sort((a,b)=>{const x=parseMeta(a),y=parseMeta(b);return (x.date||x.year||'9999').localeCompare(y.date||y.year||'9999') || a.sort-b.sort;});
  const honors=group('资质荣誉');
  const news=group('新闻与活动').sort((a,b)=>b.sort-a.sort||b.updated.localeCompare(a.updated));

  return `<section class="channel-hero about-unified-hero">
    <div class="breadcrumb"><a href="#/">首页</a><span>/</span><span>关于我们</span></div>
    <span class="eyebrow">ABOUT US · 扎根农业 · 向新而行</span>
    <h1>扎根农业现场，<br>连接产业的每一步。</h1>
    <p>${escape(s.intro||'以农业产业数字化为核心，打通生产、流通、数据要素与绿色双碳全链条，助力农业高质量发展。')}</p>
    <span class="channel-decoration" aria-hidden="true">禾</span>
  </section>

  <!-- 统一吸顶子导航栏 -->
  <nav class="about-jump sticky-subnav" aria-label="关于我们章节导航" id="about-subnav">
    <a href="#/about?section=overview" class="active" data-sec="overview">公司介绍</a>
    <a href="#/about?section=team" data-sec="team">管理团队</a>
    <a href="#/about?section=history" data-sec="history">发展历程</a>
    <a href="#/about?section=honors" data-sec="honors">资质荣誉</a>
    <a href="#/about?section=news" data-sec="news">新闻与活动</a>
    <a href="#/about?section=contact" data-sec="contact">联系合作</a>
  </nav>

  <!-- 板块一：公司介绍 -->
  <div class="about-section-wrap" id="section-overview">
    <section class="section about-intro-layout">
      <div>
        <span class="eyebrow">WHO WE ARE · 公司介绍</span>
        <h2>${escape(s.company||s.brand||'农业科技')}</h2>
        ${intro.length?blocks(intro):`<p class="muted">${escape(s.intro)}</p>`}
      </div>
      <aside class="principle-stack">
        <span class="eyebrow">OUR COMMITMENT · 服务理念</span>
        ${group('服务理念').length?blocks(group('服务理念')):[
          ['从业务现场出发','围绕生产、流通、服务与监管，明确角色、流程及数据边界。'],
          ['让能力形成协同','按项目需求组合产品，关联业务记录与证据，减少重复维护。'],
          ['与持续运营同行','通过实施联调、人员培训和使用反馈，持续完善数字化应用。']
        ].map((v,i)=>`<article><span class="principle-number">0${i+1}</span><h3>${v[0]}</h3><p>${v[1]}</p></article>`).join('')}
      </aside>
    </section>

    <section class="section capability-section" id="company-capability">
      ${heading('CAPABILITY ARCHITECTURE','业务有边界，能力有连接','围绕现有产品模块组织能力，贯穿产销全链条数字化协同。')}
      <div class="capability-layers">
        ${layers.map(v=>`<a href="#/${v[3]}"><span>${v[0]}</span><h3>${v[1]}</h3><p>${v[2]}</p><b>↗</b></a>`).join('')}
      </div>
    </section>
  </div>

  <!-- 板块二：新闻与活动 -->
  <div class="about-section-wrap" id="section-news">
    <section class="section news-section">
      ${heading('NEWS & ACTIVITIES · 新闻与活动','持续记录产业现场的新进展','以公开、可核验的内容，记录产品迭代、行业交流、生态共创与服务动态。')}
      ${news.length?`<div class="news-grid">${news.slice(0,6).map((r,i)=>`<a class="news-card" href="#/detail/${encodeURIComponent(r.id)}">
        <div class="news-card-top"><span class="news-index">${String(i+1).padStart(2,'0')}</span><span class="news-tag">${escape(r.tag||'企业动态')}</span></div>
        <h3>${escape(r.title)}</h3><p>${escape(r.summary)}</p><div class="news-card-foot"><span>阅读详情</span><b>↗</b></div>
      </a>`).join('')}</div>`:`<div class="empty wide"><h3>新闻与活动资料整理中</h3><p>产品发布、行业交流与生态活动资料正在核验归档，完成后将在此公开展示。</p><a href="#/support">了解服务支持 ↗</a></div>`}
      ${news.length>6?'<div class="section-center-action"><a class="btn-grand-outline" href="#/about?section=news">查看全部新闻与活动 ↗</a></div>':''}
    </section>
  </div>

  <!-- 板块三：管理团队 -->
  <div class="about-section-wrap" id="section-team">
    ${leaders.map(r=>{
      const m=parseMeta(r);
      return `<section class="section leadership-message">
        <div class="leadership-signature">
          <span class="eyebrow">A MESSAGE FROM OUR LEADERSHIP</span>
          <h2>${escape(m.messageTitle||'管理者寄语')}</h2>
          <strong>${escape(r.title)}</strong>
          <p>${escape(m.role||'')}</p>
          ${m.messageDate?`<small>${escape(m.messageDate)}</small>`:''}
        </div>
        <div class="leadership-body">
          ${m.messageBody.split('\n').filter(Boolean).map(t=>`<p>${escape(t)}</p>`).join('')}
          <a href="#/detail/${encodeURIComponent(r.id)}">了解完整履历 ↗</a>
        </div>
      </section>`;
    }).join('')}

    <section class="section" id="management-members">
      ${heading('OUR LEADERSHIP & EXPERTS','管理团队与专业力量','从战略规划、研发攻坚到产业实施，以专业分工服务农业产业数字化。')}
      <div class="team-toolbar" role="group" aria-label="团队分类">
        <button data-management-filter="" class="active" aria-pressed="true">全部</button>
        ${Object.entries(managementCategories).filter(([k])=>teamList.some(r=>parseMeta(r).teamCategory===k)).map(([k,v])=>`<button data-management-filter="${k}" aria-pressed="false">${v}</button>`).join('')}
      </div>
      <p id="management-count" class="muted" aria-live="polite">共 ${teamList.length} 项已发布资料</p>
      <div class="management-grid" id="management-results">
        ${teamList.length?teamList.map(managementCard).join(''):'<div class="empty wide"><h3>团队资料正在整理</h3><p>真实姓名、岗位与履历经核验授权后发布。欢迎了解我们的产品与方案方向。</p><a href="#/products">探索产品生态 ↗</a></div>'}
      </div>
    </section>
  </div>

  <!-- 板块四：发展历程 -->
  <div class="about-section-wrap" id="section-history">
    <section class="section">
      ${heading('MILESTONES · 发展历程','一路走来的关键节点','以真实的时间记录，呈现公司的成长历程、技术创新与实践成果。')}
      ${histories.length?`<div class="company-timeline">
        ${histories.map((r,i)=>{
          const m=parseMeta(r);
          const yr=m.year||`0${i+1}`;
          const isMile=m.milestone==='1';
          return `<article class="timeline-card ${isMile?'is-milestone':''}">
            <div class="timeline-badge-col">
              <span class="timeline-year">${escape(yr)}</span>
              ${m.date?`<small class="timeline-date">${escape(m.date)}</small>`:''}
              <span class="timeline-point"></span>
            </div>
            <div class="timeline-content-col">
              <div class="timeline-header">
                <h3>${escape(r.title)}</h3>
                ${isMile?'<span class="milestone-pill">★ 重点里程碑</span>':''}
              </div>
              <p class="timeline-summary">${escape(r.summary)}</p>
              <div class="timeline-body">${r.body.split('\n').filter(Boolean).map(p=>`<p>${escape(p)}</p>`).join('')}</div>
            </div>
          </article>`;
        }).join('')}
      </div>`:`<div class="empty wide"><h3>发展历程整理中</h3><p>公司关键技术突破与重大示范项目节点资料正在归档完善。</p></div>`}
    </section>
  </div>

  <!-- 板块五：资质荣誉 -->
  <div class="about-section-wrap" id="section-honors">
    <section class="section soft">
      ${heading('QUALIFICATIONS · 资质与荣誉','合规可信与荣誉积淀','展示已发布的资质与荣誉资料，有效期按登记日期判断，实际状态以官方机构核验为准。')}
      ${honors.length?`<div class="qualification-grid">
        ${honors.map(r=>{
          const m=parseMeta(r);
          const hasHttpUrl=safeVerifyUrl(m.verifyUrl);
          return `<article class="qualification-card">
            <div class="qual-badge-header">
              <span class="qual-icon" aria-hidden="true">★</span>
              <span class="qual-year">${escape(m.honorYear||'荣誉认证')}</span>
            </div>
            <h3>${escape(r.title)}</h3>
            <p class="qual-authority"><b>颁发机构</b> ${escape(m.authority||'官方权威机构')}</p>
            ${m.certNo?`<p class="qual-certno"><b>证书编号</b> <code>${escape(m.certNo)}</code></p>`:''}
            ${m.expireDate?`<p class="qual-expire ${isExpired(m.expireDate)?'is-expired':''}"><b>有效期至</b> ${escape(m.expireDate)} ${isExpired(m.expireDate)?'<span class="badge-expired">已过期</span>':'<span class="badge-valid">有效</span>'}</p>`:''}
            <p class="qual-summary">${escape(r.summary)}</p>
            ${hasHttpUrl?`<a class="qual-verify-link" href="${escape(m.verifyUrl)}" target="_blank" rel="noopener noreferrer">官方查验核对 ↗</a>`:''}
          </article>`;
        }).join('')}
      </div>`:`<div class="empty wide"><h3>资质荣誉资料整理中</h3><p>公司软件著作权、高新技术认证与行业示范荣誉正陆续录入中。</p></div>`}
    </section>
  </div>

  <!-- 板块六：联系合作 -->
  <div class="about-section-wrap" id="section-contact">
    <section class="section about-contact-unified">
      <div class="contact-info-col">
        <span class="eyebrow">CONTACT & COOPERATION · 联系合作</span>
        <h2>聊聊您的产业现场，<br>一起寻找数字化落地路径。</h2>
        <p>欢迎交流智慧农场示范基地、区域农业产业互联网平台、大宗农产品供应链协同与质量溯源建设需求。</p>
        <dl class="contact-card-list">
          ${[['商务电话',s.phone],['联系邮箱',s.email],['总部地址',s.address]].filter(v=>v[1]).map(v=>`<div><dt>${v[0]}</dt><dd>${escape(v[1])}</dd></div>`).join('')}
          <div><dt>服务时间</dt><dd>工作日 09:00 - 18:00 专家团队即时响应</dd></div>
        </dl>
        <div class="contact-cms-link">
          <a href="./admin.html">内容运营后台管理入口 ↗</a>
        </div>
      </div>

      <div class="contact-form-col">
        <div class="contact-form-card">
          <span class="eyebrow">INQUIRY FORM</span>
          <h3>在线提交合作需求</h3>
          <p class="contact-form-desc">提交的信息仅用于跟进本次咨询，由专属行业顾问与您联系。</p>
          <form id="lead-form">
            <label>您的称呼<input name="name" required maxlength="60" placeholder="例如：李先生 / 张经理" autocomplete="name"></label>
            <label>联系电话或邮箱<input name="contact" required maxlength="120" placeholder="请填写您的手机号或工作邮箱"></label>
            <label>业务需求说明<textarea name="need" required maxlength="2000" rows="4" placeholder="请简述您的业务场景、痛点、产业规模及期望了解的产品或方案"></textarea></label>
            <input name="website" class="honeypot" tabindex="-1" autocomplete="off" aria-hidden="true">
            <label class="check"><input name="consent" type="checkbox" required>我已了解上述信息用途，同意用于本次业务沟通与方案回复。</label>
            <button class="btn green" type="submit">提交合作需求 ↗</button>
            <p id="form-status" role="status" aria-live="polite"></p>
          </form>
        </div>
      </div>
    </section>
  </div>

  ${cta()}`;
}


function channel(k){

  if(k==='about') return companyAbout();

  const intros={

    products:['PRODUCT ECOSYSTEM','构建农业产业的数字底座','从生产现场到产业协同，以模块化产品能力支撑不同阶段的数字化建设。涵盖感知感知层、作业生产层、供应链流通层与可信绿色层。'],

    solutions:['INDUSTRY SOLUTIONS','深入业务场景，规划落地蓝图','围绕农业企业、示范基地、产业园区与供应链核心企业，提炼建设路径、组合产品套件与实施保障。'],

    cases:['SELECTED STORIES','真实场景，看见实践的力量','展示经过授权的项目资料，客观记录建设范围、落地举措与可核验成果，拒绝虚构。'],

    about:['ABOUT US','扎根农业，向新而生','以农业产业场景为起点，让技术、业务与持续运营共同生长。'],
    support:['SERVICE SUPPORT','服务支持，陪伴每一次落地','从业务梳理、方案设计到实施运营，提供可持续的专业支持与服务响应。'],
    partners:['ECOSYSTEM PARTNERS','连接伙伴，共建产业价值','面向设备、技术、渠道、科研与产业组织，构建开放协同的农业数字化生态。']

  };

  const [en,title,desc]=intros[k];



  // 金蝶风格的频道顶部分类/架构快捷导航

  let topBar='';

  if(k==='products'){

    topBar=`<div class="channel-subnav">

      <div class="subnav-title">按应用架构分层：</div>

      <div class="subnav-links">

        <a href="#/products?layer=all" class="${(!tag||tag==='全部')?'active':''}">全部架构层</a>

        <a href="#/products?layer=生产感知">生产与感知层</a>

        <a href="#/products?layer=产业协同">供应链协同层</a>

        <a href="#/products?layer=数据赋能">数据与资讯层</a>

        <a href="#/products?layer=可信绿色">可信与绿色层</a>

      </div>

    </div>`;

  }else if(k==='solutions'){

    topBar=`<div class="channel-subnav">

      <div class="subnav-title">适配产业主体：</div>

      <div class="subnav-links">

        <a href="#/solutions" class="active">全部方案</a>

        <a href="#/solutions?target=种植示范基地">规模化种植基地</a>

        <a href="#/solutions?target=产业园运营">产业园与区域平台</a>

        <a href="#/solutions?target=品牌供应链">农业品牌与供应链</a>

      </div>

    </div>`;

  }



  return `<section class="channel-hero"><div class="breadcrumb"><a href="#/">首页</a><span>/ ${names[k]}</span></div><span class="eyebrow">${en}</span><h1>${title}</h1><p>${desc}</p><span class="channel-decoration" aria-hidden="true">禾</span></section>

  ${topBar}

  <section class="section"><div class="toolbar"><label>搜索${names[k]}<input id="search" type="search" placeholder="输入名称、场景、适用对象或关键词" value="${escape(search)}"></label><div class="tags">${['全部',...new Set(rows(k).map(r=>r.tag).filter(Boolean))].map(t=>`<button data-tag="${escape(t)}" class="${t===tag?'active':''}" aria-pressed="${t===tag}">${escape(t)}</button>`).join('')}</div></div><p id="result-count" class="muted" aria-live="polite"></p><div class="cards-grid channel-results ${k}-grid" id="results"></div></section>

  ${k==='solutions'?`<section class="section soft">${heading('DELIVERY JOURNEY','从业务蓝图到上线运营，步步有据','金蝶式严谨交付方法，在实施前共同确认角色、业务边界与接入标准。')}<div class="delivery-steps">${[['01','业务现状梳理','现场调研基地、主体与作业痛点，确认数字化边界。'],['02','方案蓝图设计','按生产、供应链与数据服务领域，配置标准与个性化组件。'],['03','联调与实施接入','连接物联网设备、建立业务台账与接口鉴权，确保数据入库。'],['04','交付培训与持续运营','提供角色操作手册，跟踪真实使用数据，持续迭代功能。']].map(v=>`<div><span class="step-num">${v[0]}</span><h3>${v[1]}</h3><p>${v[2]}</p></div>`).join('')}</div></section>`:''}

  ${cta()}`;

}




function results(k){
  const list=rows(k).filter(r=>{
    const m=parseMeta(r);
    const metaStr=Object.values(m).join(' ');
    return (tag==='全部'||r.tag===tag)&&`${r.title} ${r.summary} ${r.body} ${metaStr}`.toLowerCase().includes(search.toLowerCase());
  });
  $('#results').innerHTML=list.length?cards(list):(!rows(k).length&&k==='cases'?caseEmpty():'<div class="empty wide"><h3>暂无匹配内容</h3><p>请调整搜索关键词或分类。</p><button class="btn green" id="reset-search">清除筛选</button></div>');
  $('#result-count').textContent=`共 ${list.length} 项内容`;
  if($('#reset-search'))$('#reset-search').onclick=()=>{search='';tag='全部';render()};
}

function detail(id){
  const r=data.records.find(v=>v.id===id || v.title===id);
  if(!r) return '<section class="section empty"><h1>内容暂不可用</h1><p>该内容可能已撤回或地址不正确。</p><a href="#/">返回首页</a></section>';
  document.title=`${r.title} · ${data.settings.brand}`;
  const m=parseMeta(r);
  const related=rows(r.channel).filter(v=>v.id!==r.id).slice(0,3);
  const list=(value)=>splitList(value).filter(Boolean);
  const bodyParts=String(r.body||'').split('\n').map(v=>v.trim()).filter(Boolean);
  const bodyHtml=bodyParts.map((p,i)=>`<p>${escape(p)}</p>`).join('');
  const channelLabel=names[r.channel]||'内容详情';
  const back=r.tag==='团队介绍'?'about?section=team':r.tag==='新闻与活动'?'about?section=news':r.channel;
  const metrics=r.channel==='cases'?list(m.outcomes).slice(0,4):r.channel==='products'?list(m.coreFeatures).slice(0,4):r.channel==='solutions'?list(m.relatedProducts).slice(0,4):[];
  const metricHtml=(r.channel==='cases'&&metrics.length)?`<div class="detail-metrics">${metrics.map((v,i)=>`<div class="detail-metric"><b>${String(i+1).padStart(2,'0')}</b><span>${escape(v)}</span></div>`).join('')}</div>`:'';
  let profile='';
  if(r.channel==='products'){
    const features=list(m.coreFeatures);
    profile=`<div class="detail-profile product-profile"><div class="profile-label">PRODUCT SYSTEM / 产品能力</div><h2>把核心能力拆成可落地的业务模块</h2><p>围绕真实生产与产业协同流程，按架构层级组织能力，让系统建设从单点应用平滑扩展到全链路运营。</p><div class="feature-matrix">${features.map((v,i)=>`<div><span>${String(i+1).padStart(2,'0')}</span><strong>${escape(v)}</strong><small>可配置 · 可追踪 · 可持续运营</small></div>`).join('')}</div></div>`;
  }else if(r.channel==='solutions'){
    const steps=[['01','业务诊断','梳理角色、流程、数据边界与现场痛点'],['02','蓝图设计','组合生产、供应链、数据与监管能力'],['03','系统接入','完成基础数据治理、接口联调与权限配置'],['04','持续运营','围绕真实使用记录持续优化与扩展']];
    const solProds=list(m.relatedProducts);
    profile=`<div class="detail-profile solution-profile"><div class="profile-label">IMPLEMENTATION BLUEPRINT / 交付蓝图</div><h2>从业务挑战到持续运营的四段路径</h2><div class="blueprint-steps">${steps.map(v=>`<div><b>${v[0]}</b><h3>${v[1]}</h3><p>${v[2]}</p></div>`).join('')}</div><div class="profile-note"><div><strong>适配产业主体：</strong>${escape(m.targetIndustry||r.tag||'现代农业产业主体')}</div><div><strong>建议交付周期：</strong>${escape(m.deliveryCycle||'根据实施范围评估')}</div>${solProds.length?`<div class="sol-prod-chips"><strong>推荐产品套件：</strong>${solProds.map(p=>`<span>${escape(p)}</span>`).join('')}</div>`:''}</div></div>`;
  }else if(r.channel==='cases'){
    const outcomes=list(m.outcomes);
    profile=`<div class="detail-profile case-profile"><div class="profile-label">CASE INTELLIGENCE / 项目纪实</div><h2>从现场挑战到可核验的建设成果</h2><div class="case-story-grid"><div><span>项目背景</span><strong>${escape(m.clientType||'农业企业 / 示范园区')}</strong><p>围绕${escape(m.caseScene||r.tag||'农业生产与产业协同')}建立可追踪、可复用的数字化业务闭环。</p></div><div><span>建设重点</span><strong>数据采集 · 流程协同 · 可信留痕</strong><p>以真实业务记录为依据，沉淀地块、设备、作业、批次及流通节点数据。</p></div></div>${outcomes.length?`<div class="evidence-list">${outcomes.map((v,i)=>`<div><b>${String(i+1).padStart(2,'0')}</b><span>${escape(v)}</span><em>已纳入项目记录</em></div>`).join('')}</div>`:''}<div class="verification-bar"><span class="live-dot"></span><b>项目资料状态</b><span>以授权资料与实际运行记录为准</span><code>TRACE / VERIFIED</code></div></div>`;
  }else if(r.channel==='about'&&r.tag==='团队介绍'){
    profile=`<div class="detail-profile team-profile">${m.portraitUrl?`<div class="team-detail-portrait"><img src="${escape(m.portraitUrl)}" alt="${escape(r.title)}"></div>`:''}<div><div class="profile-label">PEOPLE & EXPERTISE / 专业团队</div><h2>${escape(m.role||'产业数字化专业成员')}</h2><p>${escape(m.expertise||r.summary)}</p><div class="team-detail-tags">${[m.department,m.serviceScope,m.teamCategory&&managementCategories[m.teamCategory]].filter(Boolean).map(v=>`<span>${escape(v)}</span>`).join('')}</div></div></div>`;
  }else if(r.tag==='发展历程'){
    profile=`<div class="detail-profile milestone-profile"><div class="profile-label">MILESTONE / 发展节点</div><div class="milestone-date"><b>${escape(m.year||'—')}</b><span>${escape(m.date||'阶段节点')}</span></div><p>这是公司能力演进与业务实践沉淀的重要节点，相关内容以已发布的真实资料为依据。</p></div>`;
  }else if(r.tag==='资质荣誉'){
    profile=`<div class="detail-profile honor-profile"><div class="profile-label">CREDENTIAL / 资质档案</div><h2>${escape(qualificationStatus(m))}</h2><p>证书信息、颁发机构与核验入口均以运营后台登记的有效资料为准。</p>${safeVerifyUrl(m.verifyUrl)?`<a class="verify-action" href="${escape(m.verifyUrl)}" target="_blank" rel="noopener noreferrer">打开官方核验入口 ↗</a>`:''}</div>`;
  }
  return `<section class="detail-hero channel-hero"><div class="breadcrumb"><a href="#/">首页</a><span>/</span><a href="#/${r.channel}">${channelLabel}</a><span>/</span><span>${escape(r.tag||'详情')}</span></div><div class="detail-hero-grid"><div><span class="eyebrow">${escape(r.channel.toUpperCase())} / DETAIL VIEW</span><h1>${escape(r.title)}</h1><p>${escape(r.summary)}</p><div class="detail-hero-meta"><span>DATA-DRIVEN</span><span>FIELD VERIFIED</span><span>AGRI-TECH</span></div></div><div class="detail-hero-orbit" aria-hidden="true"><i></i><i></i><b>${r.channel==='cases'?'CASE':r.channel==='products'?'CORE':'PATH'}</b></div></div></section>
  <section class="section detail-overview"><div class="detail-main-column">${profile}<article class="detail-article"><div class="article-heading"><span class="eyebrow">ARCHITECTURE & RECORD / 业务档案</span><h2>项目内容与实施说明</h2></div>${bodyHtml}</article><a href="#/${back}" class="back-link">← 返回${r.tag==='团队介绍'?'关于我们 · 管理团队':channelLabel}</a></div><aside class="detail-aside detail-aside-v2"><div class="aside-signal"><span></span> DIGITAL SERVICE NODE</div><span class="eyebrow">NEXT STEP</span><h2>让方案进入真实业务现场。</h2><p>沟通业务痛点、建设范围与实施预期，获取适配的产品组合与交付路径。</p><a class="btn green" href="#/about?section=contact">预约专家咨询 ↗</a><div class="aside-service-badges"><span>✓ 场景调研</span><span>✓ 架构蓝图</span><span>✓ 系统实施</span><span>✓ 持续运营</span></div><div class="aside-code">REF / ${escape(String(r.id).slice(0,12).toUpperCase())}</div></aside></section>
  ${related.length?`<section class="section detail-related"><div class="section-title"><span class="eyebrow">EXPLORE MORE / RELATED</span><h2>继续探索同频道能力</h2><p>从相邻场景与产品能力中，找到下一步建设方向。</p></div><div class="cards-grid ${r.channel}-grid">${cards(related)}</div></section>`:''}`;
}

function contact(){
  return `<section class="channel-hero"><span class="eyebrow">CONTACT & COOPERATION</span><h1>从一次交流开始</h1><p>告诉我们您的业务场景与痛点，共同梳理适合的建设路径。</p></section>
  <section class="section contact-grid"><div><span class="eyebrow">GROW WITH US</span><h2>让数字能力，<br>在真实业务中扎根。</h2><p>欢迎交流产品应用、方案建设、产业合作与系统集成需求。</p><p class="muted">提交的信息仅用于回复本次咨询和必要的业务跟进，由官网运营人员处理，不公开展示。</p></div>
  <form id="lead-form"><label>您的称呼<input name="name" required maxlength="60" autocomplete="name"></label><label>联系电话或邮箱<input name="contact" required maxlength="120"></label><label>需求说明<textarea name="need" required maxlength="2000" rows="5" placeholder="请介绍业务场景、建设目标与希望了解的产品或方案"></textarea></label><input name="website" class="honeypot" tabindex="-1" autocomplete="off" aria-hidden="true"><label class="check"><input name="consent" type="checkbox" required>我已了解上述信息用途，同意用于本次咨询回复。</label><button class="btn green" type="submit">提交合作需求 ↗</button><p id="form-status" role="status"></p></form></section>`;
}

let aboutObserver = null;

function setupAboutSpy(){
  if(aboutObserver) { aboutObserver.disconnect(); aboutObserver = null; }
  const nav = $('#about-subnav');
  if(!nav) return;
  const sections = Array.from(document.querySelectorAll('.about-section-wrap'));
  if(!sections.length) return;

  const links = Array.from(nav.querySelectorAll('a[data-sec]'));
  const linkMap = {};
  links.forEach(a => linkMap[a.dataset.sec] = a);

  function setActive(secKey){
    links.forEach(l => {
      const isCur = l.dataset.sec === secKey;
      l.classList.toggle('active', isCur);
      if(isCur) l.setAttribute('aria-current', 'true');
      else l.removeAttribute('aria-current');
    });
  }

  // 绑定子导航点击平滑滚动
  links.forEach(a => {
    a.onclick = (e) => {
      e.preventDefault();
      const secKey = a.dataset.sec;
      const target = document.getElementById('section-' + secKey);
      if(target) {
        history.replaceState(null, '', '#/about?section=' + secKey);
        setActive(secKey);
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    };
  });

  // 滚动监听联动高亮
  if('IntersectionObserver' in window){
    aboutObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(entry.isIntersecting){
          const id = entry.target.id.replace('section-', '');
          setActive(id);
        }
      });
    }, { rootMargin: '-20% 0px -65% 0px', threshold: 0 });
    sections.forEach(s => aboutObserver.observe(s));
  }
}

function scrollToSection(secParam){
  if(!secParam) return;
  // 规范化参数名称
  let targetId = secParam;
  if(secParam.startsWith('section-')) targetId = secParam;
  else if(secParam.startsWith('company-')) targetId = 'section-' + secParam.replace('company-', '');
  else targetId = 'section-' + secParam;

  // 别名支持
  if(secParam === 'overview' || secParam === 'intro') targetId = 'section-overview';
  else if(secParam === 'team' || secParam === 'leadership') targetId = 'section-team';
  else if(secParam === 'history' || secParam === 'milestones') targetId = 'section-history';
  else if(secParam === 'honors' || secParam === 'qualifications') targetId = 'section-honors';
  else if(secParam === 'news' || secParam === 'activities') targetId = 'section-news';
  else if(secParam === 'contact' || secParam === 'cooperation') targetId = 'section-contact';

  const el = document.getElementById(targetId);
  if(el){
    setTimeout(() => {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  }
}

function render(){
  if(!data) return;
  const hash = location.hash.slice(2);
  const parts = hash.split('?')[0].split('/');
  let k = parts[0] || '';

  // 兼容老路由：自动映射到关于我们的对应板块
  if(k === 'management'){
    history.replaceState(null, '', '#/about?section=team');
    k = 'about';
  } else if(k === 'contact'){
    history.replaceState(null, '', '#/about?section=contact');
    k = 'about';
  }

  document.body.classList.toggle('is-home', !k || k === '');
  document.body.classList.toggle('is-inner', !!k);
  document.title = `${names[k] || '首页'} · ${data.settings.company || data.settings.brand || '农业科技'}`;

  // 内容渲染
  $('#main').innerHTML = k === 'detail' ? detail(decodeURIComponent(parts[1] || '')) : names[k] ? channel(k) : home();
  
  // 顶栏高亮
  const active = k === 'detail' ? data.records.find(r => r.id === parts[1])?.channel : k;
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('selected', a.hash === `#/${active}`));

  // 频道列表交互
  if(names[k] && k !== 'about'){
    results(k);
    if($('#search')) $('#search').oninput = e => { search = e.target.value; results(k); };
    document.querySelectorAll('[data-tag]').forEach(b => b.onclick = () => { tag = b.dataset.tag; render(); });
  }

  // 关于我们统一内页特有交互
  if(k === 'about'){
    setupAboutSpy();

    // 管理团队分类过滤
    document.querySelectorAll('[data-management-filter]').forEach(button => button.onclick = () => {
      const category = button.dataset.managementFilter;
      const list = rows('about').filter(r => r.tag === '团队介绍' && (!category || parseMeta(r).teamCategory === category));
      const resContainer = $('#management-results');
      if(resContainer){
        resContainer.innerHTML = list.length ? list.map(managementCard).join('') : '<div class="empty wide"><h3>暂无该分类团队资料</h3><p>可切换其他分类或在后台录入发布。</p></div>';
      }
      document.querySelectorAll('[data-management-filter]').forEach(b => {
        const on = b === button;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', on);
      });
      if($('#management-count')) $('#management-count').textContent = `共 ${list.length} 项已发布资料`;
    });

    // 锚点定位
    if(hash.includes('?section=')){
      const sec = hash.split('?section=')[1].split('&')[0];
      scrollToSection(sec);
    } else if(hash.includes('?tab=')){
      const tab = hash.split('?tab=')[1].split('&')[0];
      scrollToSection(tab);
    }
  }

  // 页脚与需求表单处理
  footer();

  if($('#lead-form')) $('#lead-form').onsubmit = async e => {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    btn.disabled = true;
    $('#form-status').textContent = '正在提交需求…';
    try {
      const f = new FormData(e.target);
      const res = await fetch('./api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: f.get('name'),
          contact: f.get('contact'),
          need: f.get('need'),
          consent: f.get('consent') === 'on',
          website: f.get('website')
        })
      });
      const json = await res.json();
      if(!res.ok) throw Error(json.error || '提交失败');
      $('#lead-form').reset();
      $('#form-status').textContent = '合作需求已提交成功，我们的行业顾问将在 1 个工作日内与您联系！';
    } catch(err) {
      $('#form-status').textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  };
}

window.onhashchange=()=>{
  search='';tag='全部';
  render();
};

async function init(){
  try{
    const menuBtn = $('#menu');
    const navEl = $('#nav');
    if(menuBtn && navEl){
      menuBtn.onclick = () => {
        const isOpen = navEl.classList.toggle('open');
        menuBtn.setAttribute('aria-expanded', String(isOpen));
      };
      navEl.querySelectorAll('a').forEach(a => {
        a.onclick = () => {
          navEl.classList.remove('open');
          menuBtn.setAttribute('aria-expanded', 'false');
        };
      });
      document.addEventListener('click', e => {
        if(!menuBtn.contains(e.target) && !navEl.contains(e.target)){
          navEl.classList.remove('open');
          menuBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }
    const res=await fetch('./api/public');
    data=await res.json();
    render();
  }catch(e){
    $('#main').innerHTML='<section class="section empty"><h1>官网正在维护中</h1><p>数据加载失败，请稍后刷新。</p></section>';
  }
}
init();
